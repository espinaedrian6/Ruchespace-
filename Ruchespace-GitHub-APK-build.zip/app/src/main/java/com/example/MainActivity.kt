package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SettingsInputComponent
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.RucheSpaceViewModel
import com.example.ui.navigation.RucheDestination
import com.example.ui.screens.CpuGpuCenterScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.GamingProfilesScreen
import com.example.ui.screens.GraphicsOptimizerScreen
import com.example.ui.screens.PerformanceTestCenterScreen
import com.example.ui.screens.RefreshRateScreen
import com.example.ui.screens.SafetyMatrixScreen
import com.example.ui.screens.ShizukuEngineScreen
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkVoid
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.RucheSpaceTheme
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {

  private val viewModel: RucheSpaceViewModel by viewModels()

  @OptIn(ExperimentalMaterial3Api::class)
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      RucheSpaceTheme {
        var currentDestination by remember { mutableStateOf(RucheDestination.DASHBOARD) }
        val uiNotice by viewModel.uiNotice.collectAsStateWithLifecycle()
        val displayInfo by viewModel.displayInfo.collectAsStateWithLifecycle()
        val shizukuState by viewModel.shizukuController.shizukuState.collectAsStateWithLifecycle()

        // BackHandler: return to Dashboard if on any sub-screen
        BackHandler(enabled = currentDestination != RucheDestination.DASHBOARD) {
          currentDestination = RucheDestination.DASHBOARD
        }

        Scaffold(
          modifier = Modifier.fillMaxSize(),
          containerColor = DarkVoid,
          topBar = {
            Column(
              modifier = Modifier
                .background(DarkSurface)
                .statusBarsPadding()
            ) {
              TopAppBar(
                title = {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                      modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(CyberCyan)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                      text = "RUCHESPACE",
                      fontSize = 18.sp,
                      fontWeight = FontWeight.Bold,
                      letterSpacing = 1.sp,
                      color = TextPrimary
                    )
                  }
                },
                actions = {
                  // Panel Refresh Rate quick pill
                  Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DarkSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
                    modifier = Modifier.padding(end = 6.dp)
                  ) {
                    Text(
                      text = "${displayInfo.currentRefreshRate.toInt()}Hz",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      color = CyberCyan,
                      fontFamily = FontFamily.Monospace,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                  }

                  // Shizuku Status pill
                  IconButton(
                    onClick = { currentDestination = RucheDestination.SHIZUKU },
                    modifier = Modifier.testTag("topbar_shizuku_btn")
                  ) {
                    Icon(
                      Icons.Default.SettingsInputComponent,
                      contentDescription = "Shizuku Engine",
                      tint = if (shizukuState.isPermissionGranted) EmeraldGlow else TextMuted
                    )
                  }

                  // Safety Matrix pill
                  IconButton(
                    onClick = { currentDestination = RucheDestination.SAFETY },
                    modifier = Modifier.testTag("topbar_safety_btn")
                  ) {
                    Icon(
                      Icons.Default.Security,
                      contentDescription = "Safety Matrix",
                      tint = if (currentDestination == RucheDestination.SAFETY) EmeraldGlow else TextSecondary
                    )
                  }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
              )

              // Scrollable Tab Row for all 8 destinations
              val destinations = RucheDestination.values()
              val selectedIndex = destinations.indexOf(currentDestination)

              ScrollableTabRow(
                selectedTabIndex = selectedIndex,
                containerColor = DarkSurface,
                contentColor = CyberCyan,
                edgePadding = 12.dp,
                indicator = { tabPositions ->
                  if (selectedIndex in tabPositions.indices) {
                    TabRowDefaults.SecondaryIndicator(
                      modifier = Modifier.tabIndicatorOffset(tabPositions[selectedIndex]),
                      color = CyberCyan,
                      height = 2.5.dp
                    )
                  }
                },
                divider = {
                  Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(DarkBorder))
                }
              ) {
                destinations.forEachIndexed { index, destination ->
                  val isSelected = destination == currentDestination
                  Tab(
                    selected = isSelected,
                    onClick = { currentDestination = destination },
                    text = {
                      Text(
                        text = destination.label,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) CyberCyan else TextSecondary
                      )
                    },
                    icon = {
                      Icon(
                        destination.icon,
                        contentDescription = destination.label,
                        tint = if (isSelected) CyberCyan else TextMuted,
                        modifier = Modifier.size(18.dp)
                      )
                    },
                    modifier = Modifier.testTag("tab_${destination.route}")
                  )
                }
              }
            }
          },
          bottomBar = {
            // Notice banner if active
            AnimatedVisibility(
              visible = uiNotice != null,
              enter = fadeIn(),
              exit = fadeOut()
            ) {
              uiNotice?.let { notice ->
                Surface(
                  color = DarkSurfaceElevated,
                  border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.5f)),
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(12.dp))
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Text(
                      text = notice,
                      fontSize = 12.sp,
                      color = TextPrimary,
                      modifier = Modifier.weight(1f)
                    )
                    IconButton(
                      onClick = { viewModel.clearUiNotice() },
                      modifier = Modifier.size(24.dp)
                    ) {
                      Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = TextSecondary, modifier = Modifier.size(16.dp))
                    }
                  }
                }
              }
            }
          }
        ) { innerPadding ->
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(innerPadding)
              .navigationBarsPadding()
          ) {
            when (currentDestination) {
              RucheDestination.DASHBOARD -> DashboardScreen(
                viewModel = viewModel,
                onNavigate = { currentDestination = it }
              )
              RucheDestination.GRAPHICS -> GraphicsOptimizerScreen(viewModel = viewModel)
              RucheDestination.REFRESH_RATE -> RefreshRateScreen(viewModel = viewModel)
              RucheDestination.CPU_GPU -> CpuGpuCenterScreen(viewModel = viewModel)
              RucheDestination.PROFILES -> GamingProfilesScreen(viewModel = viewModel)
              RucheDestination.SHIZUKU -> ShizukuEngineScreen(viewModel = viewModel)
              RucheDestination.TEST_CENTER -> PerformanceTestCenterScreen(viewModel = viewModel)
              RucheDestination.SAFETY -> SafetyMatrixScreen(viewModel = viewModel)
            }
          }
        }
      }
    }
  }
}
