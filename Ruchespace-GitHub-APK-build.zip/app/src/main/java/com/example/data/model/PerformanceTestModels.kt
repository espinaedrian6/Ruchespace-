package com.example.data.model

data class PerformanceSnapshot(
  val timestampMs: Long,
  val label: String,
  val instantaneousFps: Float,
  val rollingAverageFps: Float,
  val onePercentLowFps: Float,
  val frameTimeMs: Float,
  val frameTimeJitterMs: Float,
  val jankCount: Int,
  val batteryTempC: Float,
  val thermalStatusName: String,
  val availableRamMb: Long,
  val activeRefreshRateHz: Float
)

data class LiveBenchmarkSession(
  val id: Long = System.currentTimeMillis(),
  val sessionName: String,
  val profileName: String,
  val isRunning: Boolean,
  val elapsedSeconds: Int,
  val currentFps: Float,
  val averageFps: Float,
  val minFps: Float,
  val maxFps: Float,
  val onePercentLowFps: Float,
  val zeroPointOnePercentLowFps: Float,
  val currentFrameTimeMs: Float,
  val averageFrameTimeMs: Float,
  val jitterVarianceMs: Float,
  val totalJankFrames: Int,
  val startBatteryTempC: Float,
  val currentBatteryTempC: Float,
  val peakThermalStatus: String,
  val recentFrameTimes: List<Float> = emptyList(),
  val recentFpsPoints: List<Float> = emptyList()
)

data class BenchmarkReport(
  val id: Long,
  val testName: String,
  val profileName: String,
  val timestamp: Long,
  val durationSeconds: Int,
  val avgFps: Float,
  val minFps: Float,
  val maxFps: Float,
  val onePercentLowFps: Float,
  val avgFrameTimeMs: Float,
  val jitterMs: Float,
  val stuttersTotal: Int,
  val batteryStartTemp: Float,
  val batteryEndTemp: Float,
  val thermalStatusPeak: String,
  val deviceModel: String,
  val androidVersion: String,
  val notes: String
)
