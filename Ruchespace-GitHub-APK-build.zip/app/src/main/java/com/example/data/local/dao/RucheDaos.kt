package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.PerformanceReportEntity
import com.example.data.local.entity.SettingBackupEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ReportDao {
  @Query("SELECT * FROM performance_reports ORDER BY timestamp DESC")
  fun getAllReports(): Flow<List<PerformanceReportEntity>>

  @Query("SELECT * FROM performance_reports WHERE id = :id LIMIT 1")
  suspend fun getReportById(id: Long): PerformanceReportEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertReport(report: PerformanceReportEntity): Long

  @Query("DELETE FROM performance_reports WHERE id = :id")
  suspend fun deleteReportById(id: Long)

  @Query("DELETE FROM performance_reports")
  suspend fun deleteAllReports()
}

@Dao
interface SettingBackupDao {
  @Query("SELECT * FROM setting_backups WHERE settingKey = :key LIMIT 1")
  suspend fun getBackup(key: String): SettingBackupEntity?

  @Query("SELECT * FROM setting_backups")
  fun getAllBackups(): Flow<List<SettingBackupEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveBackup(backup: SettingBackupEntity)

  @Query("DELETE FROM setting_backups WHERE settingKey = :key")
  suspend fun deleteBackup(key: String)
}
