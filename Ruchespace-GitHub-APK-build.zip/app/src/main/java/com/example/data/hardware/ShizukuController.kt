package com.example.data.hardware

import android.content.Context
import android.content.pm.PackageManager
import com.example.data.model.ShizukuOperationId
import com.example.data.model.ShizukuState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

data class ShizukuExecutionResult(
  val isSuccess: Boolean,
  val output: String,
  val errorOutput: String,
  val exitCode: Int,
  val securityNotice: String
)

class ShizukuController(private val context: Context) {

  private val _shizukuState = MutableStateFlow(
    ShizukuState(
      isServiceAvailable = false,
      isBinderAlive = false,
      isPermissionGranted = false,
      shizukuVersion = 0,
      serverUid = -1,
      connectionStatusText = "Checking Shizuku Binder..."
    )
  )
  val shizukuState: StateFlow<ShizukuState> = _shizukuState.asStateFlow()

  private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
    refreshShizukuStatus()
  }

  private val binderDeadListener = Shizuku.OnBinderDeadListener {
    refreshShizukuStatus()
  }

  private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
    if (requestCode == REQUEST_CODE_SHIZUKU_PERMISSION) {
      refreshShizukuStatus()
    }
  }

  init {
    try {
      Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
      Shizuku.addBinderDeadListener(binderDeadListener)
      Shizuku.addRequestPermissionResultListener(permissionResultListener)
      refreshShizukuStatus()
    } catch (_: Throwable) {
      _shizukuState.value = ShizukuState(
        isServiceAvailable = false,
        isBinderAlive = false,
        isPermissionGranted = false,
        shizukuVersion = 0,
        serverUid = -1,
        connectionStatusText = "Shizuku not installed or server not started."
      )
    }
  }

  fun refreshShizukuStatus() {
    try {
      val isBinderAlive = Shizuku.pingBinder()
      if (!isBinderAlive) {
        _shizukuState.value = ShizukuState(
          isServiceAvailable = false,
          isBinderAlive = false,
          isPermissionGranted = false,
          shizukuVersion = 0,
          serverUid = -1,
          connectionStatusText = "Shizuku service is not running. Launch the Shizuku app and start via Wireless Debugging or ADB."
        )
        return
      }

      val hasPermission = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
      } catch (_: Throwable) {
        false
      }

      val version = try { Shizuku.getVersion() } catch (_: Throwable) { 0 }
      val uid = try { Shizuku.getUid() } catch (_: Throwable) { -1 }

      val statusText = when {
        hasPermission -> "Connected & Authorized (Shizuku v$version, UID $uid - ADB privileges active)"
        else -> "Service running, but permission not granted. Tap 'Grant Shizuku Permission'."
      }

      _shizukuState.value = ShizukuState(
        isServiceAvailable = true,
        isBinderAlive = true,
        isPermissionGranted = hasPermission,
        shizukuVersion = version,
        serverUid = uid,
        connectionStatusText = statusText
      )
    } catch (e: Throwable) {
      _shizukuState.value = ShizukuState(
        isServiceAvailable = false,
        isBinderAlive = false,
        isPermissionGranted = false,
        shizukuVersion = 0,
        serverUid = -1,
        connectionStatusText = "Binder error: ${e.message}"
      )
    }
  }

  fun requestPermission() {
    try {
      if (Shizuku.pingBinder()) {
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
          Shizuku.requestPermission(REQUEST_CODE_SHIZUKU_PERMISSION)
        }
      }
    } catch (_: Throwable) {
      refreshShizukuStatus()
    }
  }

  suspend fun executeAllowlistedOperation(
    opId: ShizukuOperationId,
    param: String = ""
  ): ShizukuExecutionResult = withContext(Dispatchers.IO) {
    if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
      return@withContext ShizukuExecutionResult(
        isSuccess = false,
        output = "",
        errorOutput = "Shizuku permission not granted or service offline.",
        exitCode = -1,
        securityNotice = "Elevated operation blocked by security guardrails."
      )
    }

    // Strict allowlist validation
    val cmdArray: Array<String> = when (opId) {
      ShizukuOperationId.SET_PEAK_REFRESH_RATE -> {
        val rate = param.toFloatOrNull()
        if (rate == null || rate < 30f || rate > 240f) {
          return@withContext ShizukuExecutionResult(
            isSuccess = false, output = "", errorOutput = "Invalid refresh rate param: $param", exitCode = 1,
            securityNotice = "Validation failed: rate must be between 30 and 240 Hz."
          )
        }
        arrayOf("sh", "-c", "settings put system peak_refresh_rate $rate")
      }
      ShizukuOperationId.SET_MIN_REFRESH_RATE -> {
        val rate = param.toFloatOrNull()
        if (rate == null || rate < 30f || rate > 240f) {
          return@withContext ShizukuExecutionResult(
            isSuccess = false, output = "", errorOutput = "Invalid refresh rate param: $param", exitCode = 1,
            securityNotice = "Validation failed: rate must be between 30 and 240 Hz."
          )
        }
        arrayOf("sh", "-c", "settings put system min_refresh_rate $rate")
      }
      ShizukuOperationId.RESET_REFRESH_RATE -> {
        arrayOf("sh", "-c", "settings delete system peak_refresh_rate ; settings delete system min_refresh_rate")
      }
      ShizukuOperationId.SET_DISPLAY_DENSITY -> {
        val dpi = param.toIntOrNull()
        if (dpi == null || dpi !in 160..640) {
          return@withContext ShizukuExecutionResult(
            isSuccess = false, output = "", errorOutput = "Invalid density DPI: $param", exitCode = 1,
            securityNotice = "Safety guardrail: DPI must remain within 160..640 to prevent interface truncation."
          )
        }
        arrayOf("sh", "-c", "wm density $dpi")
      }
      ShizukuOperationId.RESET_DISPLAY_DENSITY -> {
        arrayOf("sh", "-c", "wm density reset")
      }
      ShizukuOperationId.QUERY_SURFACEFLINGER_FPS -> {
        arrayOf("sh", "-c", "dumpsys SurfaceFlinger --latency")
      }
      ShizukuOperationId.TEST_BINDER_ECHO -> {
        arrayOf("sh", "-c", "echo 'Shizuku IPC operational'")
      }
    }

    try {
      val newProcessMethod = Shizuku::class.java.getDeclaredMethod(
        "newProcess",
        Array<String>::class.java,
        Array<String>::class.java,
        String::class.java
      )
      newProcessMethod.isAccessible = true
      val process = newProcessMethod.invoke(null, cmdArray, null, null) as Process
      val reader = BufferedReader(InputStreamReader(process.inputStream))
      val errReader = BufferedReader(InputStreamReader(process.errorStream))

      val outputBuilder = StringBuilder()
      var line: String?
      while (reader.readLine().also { line = it } != null) {
        outputBuilder.appendLine(line)
      }

      val errBuilder = StringBuilder()
      while (errReader.readLine().also { line = it } != null) {
        errBuilder.appendLine(line)
      }

      val exitCode = process.waitFor()

      val isSuccess = exitCode == 0 && errBuilder.isBlank()
      val securityNotice = if (isSuccess) {
        "Executed safely under Shizuku ADB sandbox. Zero system files modified."
      } else {
        "Command returned non-zero code or error. Check manufacturer permissions (e.g., Xiaomi 'USB debugging (Security settings)')."
      }

      ShizukuExecutionResult(
        isSuccess = isSuccess,
        output = outputBuilder.toString().trim(),
        errorOutput = errBuilder.toString().trim(),
        exitCode = exitCode,
        securityNotice = securityNotice
      )
    } catch (e: Throwable) {
      ShizukuExecutionResult(
        isSuccess = false,
        output = "",
        errorOutput = e.localizedMessage ?: "Unknown IPC error",
        exitCode = -1,
        securityNotice = "Execution failed due to system exception: ${e.message}"
      )
    }
  }

  fun unregister() {
    try {
      Shizuku.removeBinderReceivedListener(binderReceivedListener)
      Shizuku.removeBinderDeadListener(binderDeadListener)
      Shizuku.removeRequestPermissionResultListener(permissionResultListener)
    } catch (_: Throwable) {}
  }

  companion object {
    const val REQUEST_CODE_SHIZUKU_PERMISSION = 7001
  }
}
