package com.example.data.model

enum class ProfileId(val displayName: String) {
  MAX_PERFORMANCE("Maximum Supported Performance"),
  COMPETITIVE("Competitive Gaming"),
  BALANCED("Balanced Gaming"),
  BATTERY_SAVER("Battery Saver"),
  LOW_GRAPHICS_STABLE_FPS("Low Graphics / Stable FPS"),
  CUSTOM("Custom Graphics")
}

data class GamingProfileConfig(
  val id: ProfileId,
  val name: String,
  val subtitle: String,
  val iconKey: String,
  val preferredRefreshRate: Float?, // null = system default/auto
  val fpsTargetCap: Int,
  val touchResponsePriority: Boolean,
  val thermalThrottlingAwareness: String,
  val backgroundProcessPolicy: String,
  val resolutionScalePercent: Int,
  val renderResolutionNotice: String,
  val isRecommendedForSoC: Boolean
)

data class ProfileApplicationReport(
  val profileId: ProfileId,
  val profileName: String,
  val appliedAtEpochMs: Long,
  val changesApplied: List<String>,
  val backupSummary: String,
  val activeNotice: String,
  val undoAvailable: Boolean
)

val DEFAULT_GAMING_PROFILES: List<GamingProfileConfig> = listOf(
  GamingProfileConfig(
    id = ProfileId.MAX_PERFORMANCE,
    name = "Maximum Supported Performance",
    subtitle = "Pins the highest verified refresh rate and prioritizes frame responsiveness.",
    iconKey = "speed",
    preferredRefreshRate = 120f,
    fpsTargetCap = 120,
    touchResponsePriority = true,
    thermalThrottlingAwareness = "Aggressive cooling advice; monitors thermal headroom without tampering hardware limits.",
    backgroundProcessPolicy = "Close background non-essential applications to free L3 CPU cache.",
    resolutionScalePercent = 100,
    renderResolutionNotice = "Full native resolution maintained. GPU render load is high.",
    isRecommendedForSoC = true
  ),
  GamingProfileConfig(
    id = ProfileId.COMPETITIVE,
    name = "Competitive Gaming",
    subtitle = "Zero latency bias: stable 90/120Hz refresh rate, low jitter, maximum touch polling.",
    iconKey = "sports_esports",
    preferredRefreshRate = 90f,
    fpsTargetCap = 90,
    touchResponsePriority = true,
    thermalThrottlingAwareness = "Sustained temperature target: preserves steady 90 FPS rather than brief peak.",
    backgroundProcessPolicy = "Recommended: Do Not Disturb and suspend background sync.",
    resolutionScalePercent = 100,
    renderResolutionNotice = "Optimized for fast visual tracking and minimum input lag.",
    isRecommendedForSoC = true
  ),
  GamingProfileConfig(
    id = ProfileId.BALANCED,
    name = "Balanced Gaming",
    subtitle = "Default daily profile. 60Hz/90Hz adaptive display mode with standard thermal curves.",
    iconKey = "tune",
    preferredRefreshRate = 60f,
    fpsTargetCap = 60,
    touchResponsePriority = false,
    thermalThrottlingAwareness = "Standard OEM thermal dissipation. Never heats above 41°C.",
    backgroundProcessPolicy = "Standard Android multitasking preserved.",
    resolutionScalePercent = 100,
    renderResolutionNotice = "Original display scale untouched. Ideal for casual and story games.",
    isRecommendedForSoC = true
  ),
  GamingProfileConfig(
    id = ProfileId.BATTERY_SAVER,
    name = "Battery Saver",
    subtitle = "Cuts GPU/display power consumption by up to 40% using 60Hz and lower framerate limits.",
    iconKey = "battery_saver",
    preferredRefreshRate = 60f,
    fpsTargetCap = 45,
    touchResponsePriority = false,
    thermalThrottlingAwareness = "Runs cool (<37°C) even during 3-hour gaming sessions.",
    backgroundProcessPolicy = "Conserves battery by reducing background wakeups.",
    resolutionScalePercent = 85,
    renderResolutionNotice = "Optional 85% safe scaling reduces pixel fillrate stress.",
    isRecommendedForSoC = false
  ),
  GamingProfileConfig(
    id = ProfileId.LOW_GRAPHICS_STABLE_FPS,
    name = "Low Graphics / Stable FPS",
    subtitle = "For mid-range or thermal-sensitive chipsets: flat frame-time line over flashy effects.",
    iconKey = "show_chart",
    preferredRefreshRate = 60f,
    fpsTargetCap = 60,
    touchResponsePriority = true,
    thermalThrottlingAwareness = "Avoids thermal cliff drops. Keeps 1% low FPS above 55.",
    backgroundProcessPolicy = "Clears stale cache memory before launching heavy 3D titles.",
    resolutionScalePercent = 75,
    renderResolutionNotice = "Recommended in-game low shadows and 75% render scale for rock-solid 60 FPS.",
    isRecommendedForSoC = false
  ),
  GamingProfileConfig(
    id = ProfileId.CUSTOM,
    name = "Custom Graphics",
    subtitle = "User-defined manual parameters for refresh rate, FPS limit, and scaling.",
    iconKey = "settings_suggest",
    preferredRefreshRate = null,
    fpsTargetCap = 60,
    touchResponsePriority = false,
    thermalThrottlingAwareness = "Custom threshold warnings.",
    backgroundProcessPolicy = "User managed.",
    resolutionScalePercent = 100,
    renderResolutionNotice = "Customized by user.",
    isRecommendedForSoC = false
  )
)
