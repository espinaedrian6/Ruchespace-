package com.example.data.model

data class ShizukuState(
  val isServiceAvailable: Boolean,
  val isBinderAlive: Boolean,
  val isPermissionGranted: Boolean,
  val shizukuVersion: Int,
  val serverUid: Int,
  val connectionStatusText: String
)

enum class ShizukuOperationId {
  SET_PEAK_REFRESH_RATE,
  SET_MIN_REFRESH_RATE,
  RESET_REFRESH_RATE,
  SET_DISPLAY_DENSITY,
  RESET_DISPLAY_DENSITY,
  QUERY_SURFACEFLINGER_FPS,
  TEST_BINDER_ECHO
}

data class AllowlistedOperation(
  val id: ShizukuOperationId,
  val title: String,
  val description: String,
  val commandPattern: String,
  val isSafelyReversible: Boolean,
  val vendorSupportNote: String
)

data class ManufacturerSecurityInfo(
  val manufacturer: String,
  val restrictionName: String,
  val symptoms: String,
  val technicalCause: String,
  val userActionRequired: String
)

val ALLOWLISTED_OPERATIONS: List<AllowlistedOperation> = listOf(
  AllowlistedOperation(
    id = ShizukuOperationId.SET_PEAK_REFRESH_RATE,
    title = "Set System Peak Refresh Rate",
    description = "Writes the preferred upper refresh rate limit to Settings.System without requiring root.",
    commandPattern = "settings put system peak_refresh_rate <rate>",
    isSafelyReversible = true,
    vendorSupportNote = "Works on Google Pixel, Motorola, Sony, Nothing OS, and AOSP-based ROMs."
  ),
  AllowlistedOperation(
    id = ShizukuOperationId.SET_MIN_REFRESH_RATE,
    title = "Set System Minimum Refresh Rate",
    description = "Forces the panel refresh rate floor to prevent idle drops when smooth gaming is active.",
    commandPattern = "settings put system min_refresh_rate <rate>",
    isSafelyReversible = true,
    vendorSupportNote = "Reduces VRR adaptive jitter on supported high-refresh panels."
  ),
  AllowlistedOperation(
    id = ShizukuOperationId.RESET_REFRESH_RATE,
    title = "Reset Refresh Rate to Defaults",
    description = "Deletes or resets user-overridden refresh rate limits back to factory adaptive defaults.",
    commandPattern = "settings delete system peak_refresh_rate && settings delete system min_refresh_rate",
    isSafelyReversible = true,
    vendorSupportNote = "Universal safe reset."
  ),
  AllowlistedOperation(
    id = ShizukuOperationId.SET_DISPLAY_DENSITY,
    title = "Set Display Density (DPI)",
    description = "Adjusts window manager display density using validated DPI boundaries with auto-revert protection.",
    commandPattern = "wm density <dpi>",
    isSafelyReversible = true,
    vendorSupportNote = "Must stay within safe bounds (160 to 640 DPI) to prevent UI truncation."
  ),
  AllowlistedOperation(
    id = ShizukuOperationId.RESET_DISPLAY_DENSITY,
    title = "Reset Display Density",
    description = "Restores original factory display density via window manager.",
    commandPattern = "wm density reset",
    isSafelyReversible = true,
    vendorSupportNote = "Always safe to execute."
  ),
  AllowlistedOperation(
    id = ShizukuOperationId.QUERY_SURFACEFLINGER_FPS,
    title = "Query SurfaceFlinger Frame Timings",
    description = "Reads compositor frame timestamps from SurfaceFlinger to evaluate system frame delivery.",
    commandPattern = "dumpsys SurfaceFlinger --latency",
    isSafelyReversible = true,
    vendorSupportNote = "Read-only diagnostic query. Zero risk of system modification."
  )
)

val KNOWN_MANUFACTURER_RESTRICTIONS: List<ManufacturerSecurityInfo> = listOf(
  ManufacturerSecurityInfo(
    manufacturer = "Xiaomi / Redmi / POCO (MIUI / HyperOS)",
    restrictionName = "USB Debugging (Security Settings) Requirement",
    symptoms = "Shizuku commands fail with SecurityException or 'Permission denied' even when Shizuku shows connected.",
    technicalCause = "Xiaomi blocks simulated input and Settings modification over ADB unless explicitly unlocked with a Mi Account SIM card.",
    userActionRequired = "Developer Options -> Enable 'USB debugging (Security settings)'. Requires internet and SIM card insertion on Xiaomi devices."
  ),
  ManufacturerSecurityInfo(
    manufacturer = "Samsung (One UI)",
    restrictionName = "Dynamic AMOLED 2X Refresh Rate Policy",
    symptoms = "Setting 120Hz system-wide might be overridden back to 60Hz when thermal threshold is reached or in power saving mode.",
    technicalCause = "Samsung Knox and Game Optimizing Service (GOS) intercept display modes to enforce device thermal protection.",
    userActionRequired = "Ensure Power Saving Mode is OFF and Device Care thermal throttling is monitored. RucheSpace respects Samsung hardware limits."
  ),
  ManufacturerSecurityInfo(
    manufacturer = "OnePlus / OPPO / Realme (ColorOS / OxygenOS)",
    restrictionName = "Per-App 60Hz Whitelist Lock",
    symptoms = "Display runs at 120Hz on home screen, but drops to 60Hz as soon as a 3D game launches.",
    technicalCause = "ColorOS contains a proprietary display daemon that caps games to 60Hz unless the app ID is hardcoded in the OEM whitelist.",
    userActionRequired = "In ColorOS Settings -> Display & Brightness -> Screen Refresh Rate -> App-specific refresh rate -> Set target game to 120Hz."
  ),
  ManufacturerSecurityInfo(
    manufacturer = "Huawei / Honor (EMUI / MagicOS)",
    restrictionName = "Heavy Background Process Termination",
    symptoms = "Shizuku binder service or background diagnostics killed immediately after switching apps.",
    technicalCause = "Aggressive PowerGenie daemon kills background processes not in Huawei whitelist.",
    userActionRequired = "Battery Settings -> App Launch -> RucheSpace -> Manage Manually (Allow Auto-launch, Secondary launch, and Run in background)."
  )
)
