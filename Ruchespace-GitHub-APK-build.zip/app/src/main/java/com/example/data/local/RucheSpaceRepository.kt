package com.example.data.local

import com.example.data.local.dao.ReportDao
import com.example.data.local.dao.SettingBackupDao
import com.example.data.local.entity.PerformanceReportEntity
import com.example.data.local.entity.SettingBackupEntity
import kotlinx.coroutines.flow.Flow

class RucheSpaceRepository(
  private val reportDao: ReportDao,
  private val settingBackupDao: SettingBackupDao
) {
  val allReports: Flow<List<PerformanceReportEntity>> = reportDao.getAllReports()
  val allBackups: Flow<List<SettingBackupEntity>> = settingBackupDao.getAllBackups()

  suspend fun saveReport(report: PerformanceReportEntity): Long {
    return reportDao.insertReport(report)
  }

  suspend fun deleteReport(id: Long) {
    reportDao.deleteReportById(id)
  }

  suspend fun clearAllReports() {
    reportDao.deleteAllReports()
  }

  suspend fun getBackup(key: String): SettingBackupEntity? {
    return settingBackupDao.getBackup(key)
  }

  suspend fun saveBackup(key: String, originalValue: String) {
    settingBackupDao.saveBackup(
      SettingBackupEntity(
        settingKey = key,
        originalValue = originalValue,
        backupTimestamp = System.currentTimeMillis()
      )
    )
  }

  suspend fun removeBackup(key: String) {
    settingBackupDao.deleteBackup(key)
  }
}
