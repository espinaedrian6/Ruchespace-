package com.example.data.model

enum class CapabilitySupportLevel(
  val badgeLabel: String,
  val badgeColor: Long,
  val description: String
) {
  SUPPORTED_ANDROID_API("Supported", 0xFF10B981, "Runs via standard documented Android SDK APIs without extra permissions."),
  REQUIRES_SHIZUKU("Requires Shizuku", 0xFF3B82F6, "Requires ADB-level bridge permission granted through Shizuku app."),
  REQUIRES_ROOT_DISALLOWED("Requires Root (Disallowed)", 0xFFEF4444, "Requires unlocked bootloader & kernel privileges. RucheSpace intentionally does not require or execute root hacks to protect device integrity."),
  UNSUPPORTED_BY_HARDWARE("Hardware Limited", 0xFF64748B, "Physical display panel, SoC, or OEM thermal driver does not support this feature."),
  NOT_TESTED("Not Tested", 0xFFF59E0B, "Untested on this specific Android build / OEM manufacturer layer.")
}

data class SafetyCapability(
  val id: String,
  val title: String,
  val category: String, // e.g. "Graphics & Display", "Hardware & Thermal", "Frame Control", "System Tuning"
  val supportLevel: CapabilitySupportLevel,
  val explanation: String,
  val technicalGuardrail: String,
  val safeAlternative: String
)

val SYSTEM_SAFETY_CAPABILITIES: List<SafetyCapability> = listOf(
  SafetyCapability(
    id = "read_display_modes",
    title = "Query Display Modes & Refresh Rates",
    category = "Display & Refresh",
    supportLevel = CapabilitySupportLevel.SUPPORTED_ANDROID_API,
    explanation = "Queries android.view.Display.getSupportedModes() and DisplayManager APIs natively.",
    technicalGuardrail = "Read-only system query. Zero risk of device corruption.",
    safeAlternative = "Integrated natively in RucheSpace."
  ),
  SafetyCapability(
    id = "app_refresh_rate",
    title = "Window Preferred Refresh Rate",
    category = "Display & Refresh",
    supportLevel = CapabilitySupportLevel.SUPPORTED_ANDROID_API,
    explanation = "Applies window.attributes.preferredDisplayModeId for supported in-app surfaces.",
    technicalGuardrail = "Scoped to current foreground window. System gracefully reverts upon app exit.",
    safeAlternative = "Used by RucheSpace for diagnostic and test windows."
  ),
  SafetyCapability(
    id = "system_peak_refresh_rate",
    title = "System-Wide Peak & Min Refresh Rate",
    category = "Display & Refresh",
    supportLevel = CapabilitySupportLevel.REQUIRES_SHIZUKU,
    explanation = "Modifies Settings.System 'peak_refresh_rate' and 'min_refresh_rate'. Requires WRITE_SECURE_SETTINGS or Shizuku permission.",
    technicalGuardrail = "Strictly checked against Display.getSupportedModes(). Unsupported values are blocked before execution.",
    safeAlternative = "One-tap reset restores default adaptive behavior anytime."
  ),
  SafetyCapability(
    id = "resolution_scaling",
    title = "Display Density & Resolution Scaling",
    category = "Graphics & Display",
    supportLevel = CapabilitySupportLevel.REQUIRES_SHIZUKU,
    explanation = "Changes display density (DPI) and surface size via WindowManager shell bridge.",
    technicalGuardrail = "Protected by RucheSpace 10-second automatic revert countdown. If user doesn't confirm, original settings are automatically restored.",
    safeAlternative = "In-game render scale adjustment is recommended first."
  ),
  SafetyCapability(
    id = "live_fps_diagnostics",
    title = "Choreographer Frame-Time & FPS Diagnostics",
    category = "Frame Control",
    supportLevel = CapabilitySupportLevel.SUPPORTED_ANDROID_API,
    explanation = "Measures exact frame presentation intervals using Android Choreographer FrameCallback in real-time.",
    technicalGuardrail = "No kernel hooks or bytecode injection required. High accuracy without performance penalty.",
    safeAlternative = "True measured frame timings, never fabricated."
  ),
  SafetyCapability(
    id = "in_game_graphics_unlock",
    title = "Third-Party Game Internal Graphics Unlock",
    category = "Frame Control",
    supportLevel = CapabilitySupportLevel.REQUIRES_ROOT_DISALLOWED,
    explanation = "Changing an external game's internal graphics assets (texture quality, shadow maps, unlocked 120 FPS config) requires altering the game's internal data directory or memory injection.",
    technicalGuardrail = "Android sandbox security (SELinux) strictly prohibits external apps from tampering with another app's memory or files without root. RucheSpace will NEVER compromise app sandbox security or risk user account bans.",
    safeAlternative = "RucheSpace provides verified, game-specific in-game settings guides to set optimal visuals safely from inside each game."
  ),
  SafetyCapability(
    id = "cpu_gpu_overclocking",
    title = "CPU / GPU Frequency Overclocking & Overvolting",
    category = "Hardware & Thermal",
    supportLevel = CapabilitySupportLevel.REQUIRES_ROOT_DISALLOWED,
    explanation = "Overclocking CPU or GPU frequencies beyond OEM kernel limits requires custom kernel modules, unlocked bootloader, and root privileges.",
    technicalGuardrail = "RucheSpace NEVER claims to overclock frequencies or bypass thermal limits. Bypassing thermal limits leads to silicon degradation and battery swelling.",
    safeAlternative = "RucheSpace monitors thermal headroom, guides cooling, and diagnoses bottlenecks so your device sustains its peak factory boost clocks."
  ),
  SafetyCapability(
    id = "thermal_status_monitoring",
    title = "Thermal Status & Headroom Telemetry",
    category = "Hardware & Thermal",
    supportLevel = CapabilitySupportLevel.SUPPORTED_ANDROID_API,
    explanation = "Monitors PowerManager.getThermalHeadroom() and OnThermalStatusChangedListener on Android 10+ (API 29+).",
    technicalGuardrail = "Standard Android platform API designed for game engines to adaptively throttle visuals before hard stutter occurs.",
    safeAlternative = "Fully integrated with real-time HUD alerts."
  ),
  SafetyCapability(
    id = "battery_telemetry",
    title = "Battery Temperature & Health Telemetry",
    category = "Hardware & Thermal",
    supportLevel = CapabilitySupportLevel.SUPPORTED_ANDROID_API,
    explanation = "Receives hardware battery temperature, voltage, and health metrics from system BatteryManager broadcast.",
    technicalGuardrail = "Standard read-only broadcast without special permissions.",
    safeAlternative = "Accurate to 0.1°C."
  )
)
