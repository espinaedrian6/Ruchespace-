package com.example.data.hardware

import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.roundToInt
import kotlin.math.sqrt

data class FpsFrameMetrics(
  val instantFps: Float = 0f,
  val rollingFps: Float = 0f,
  val onePercentLowFps: Float = 0f,
  val zeroPointOnePercentLowFps: Float = 0f,
  val currentFrameTimeMs: Float = 0f,
  val avgFrameTimeMs: Float = 0f,
  val frameTimeJitterMs: Float = 0f,
  val totalFramesCount: Long = 0,
  val jankFramesCount: Int = 0,
  val frameHistoryMs: List<Float> = emptyList(), // last 60 frames for drawing live chart
  val fpsHistory: List<Float> = emptyList() // last 30 1-sec points
)

class RealFpsTracker : Choreographer.FrameCallback {

  private var isTracking = false
  private var lastFrameTimeNs: Long = 0L

  private val frameDeltasNs = ArrayDeque<Long>(120)
  private val frameTimesMsHistory = ArrayDeque<Float>(60)
  private val fpsHistoryList = ArrayDeque<Float>(30)

  private var totalFramesSampled: Long = 0L
  private var totalJankFrames: Int = 0
  private var lastSecondEpochMs: Long = System.currentTimeMillis()
  private var framesInCurrentSecond: Int = 0

  private val _metrics = MutableStateFlow(FpsFrameMetrics())
  val metrics: StateFlow<FpsFrameMetrics> = _metrics.asStateFlow()

  private val mainHandler = Handler(Looper.getMainLooper())

  fun startTracking() {
    if (isTracking) return
    isTracking = true
    lastFrameTimeNs = 0L
    frameDeltasNs.clear()
    frameTimesMsHistory.clear()
    totalFramesSampled = 0L
    totalJankFrames = 0
    lastSecondEpochMs = System.currentTimeMillis()
    framesInCurrentSecond = 0

    mainHandler.post {
      Choreographer.getInstance().postFrameCallback(this)
    }
  }

  fun stopTracking() {
    isTracking = false
    mainHandler.post {
      Choreographer.getInstance().removeFrameCallback(this)
    }
  }

  override fun doFrame(frameTimeNanos: Long) {
    if (!isTracking) return

    if (lastFrameTimeNs > 0) {
      val deltaNs = frameTimeNanos - lastFrameTimeNs
      if (deltaNs > 0) {
        val frameTimeMs = deltaNs / 1_000_000.0f
        val instantFps = (1_000_000_000.0 / deltaNs).toFloat().coerceIn(1f, 360f)

        if (frameDeltasNs.size >= 120) {
          frameDeltasNs.removeFirst()
        }
        frameDeltasNs.addLast(deltaNs)

        if (frameTimesMsHistory.size >= 60) {
          frameTimesMsHistory.removeFirst()
        }
        frameTimesMsHistory.addLast(frameTimeMs)

        totalFramesSampled++
        framesInCurrentSecond++

        // A frame is considered jank if it took > 20ms (> 1.25x normal 60Hz frame time)
        if (frameTimeMs > 20f) {
          totalJankFrames++
        }

        val now = System.currentTimeMillis()
        if (now - lastSecondEpochMs >= 1000) {
          val secondFps = framesInCurrentSecond.toFloat()
          if (fpsHistoryList.size >= 30) {
            fpsHistoryList.removeFirst()
          }
          fpsHistoryList.addLast(secondFps)
          framesInCurrentSecond = 0
          lastSecondEpochMs = now
        }

        // Calculate 1% low and 0.1% low
        val sortedTimes = frameTimesMsHistory.toList().sorted()
        val avgFrameTime = if (frameTimesMsHistory.isNotEmpty()) frameTimesMsHistory.average().toFloat() else 16.6f
        val rollingFps = if (avgFrameTime > 0) (1000f / avgFrameTime).coerceIn(1f, 360f) else instantFps

        val p99Index = (sortedTimes.size * 0.99).roundToInt().coerceIn(0, sortedTimes.size - 1)
        val p999Index = (sortedTimes.size * 0.999).roundToInt().coerceIn(0, sortedTimes.size - 1)
        val p99Time = if (sortedTimes.isNotEmpty()) sortedTimes[p99Index] else 16.6f
        val p999Time = if (sortedTimes.isNotEmpty()) sortedTimes[p999Index] else 16.6f

        val onePercentLowFps = if (p99Time > 0) (1000f / p99Time).coerceIn(1f, 360f) else rollingFps
        val zeroPointOnePercentLowFps = if (p999Time > 0) (1000f / p99Time).coerceIn(1f, 360f) else rollingFps

        // Compute frame-time jitter (standard deviation)
        var varianceSum = 0.0
        for (time in frameTimesMsHistory) {
          val diff = time - avgFrameTime
          varianceSum += diff * diff
        }
        val jitterMs = if (frameTimesMsHistory.size > 1) {
          sqrt(varianceSum / frameTimesMsHistory.size).toFloat()
        } else 0f

        _metrics.value = FpsFrameMetrics(
          instantFps = instantFps,
          rollingFps = rollingFps,
          onePercentLowFps = onePercentLowFps,
          zeroPointOnePercentLowFps = zeroPointOnePercentLowFps,
          currentFrameTimeMs = frameTimeMs,
          avgFrameTimeMs = avgFrameTime,
          frameTimeJitterMs = jitterMs,
          totalFramesCount = totalFramesSampled,
          jankFramesCount = totalJankFrames,
          frameHistoryMs = frameTimesMsHistory.toList(),
          fpsHistory = fpsHistoryList.toList()
        )
      }
    }

    lastFrameTimeNs = frameTimeNanos

    if (isTracking) {
      Choreographer.getInstance().postFrameCallback(this)
    }
  }
}
