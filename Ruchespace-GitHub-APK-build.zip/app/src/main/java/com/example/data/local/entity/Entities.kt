package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "performance_reports")
data class PerformanceReportEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val testName: String,
  val profileName: String,
  val timestamp: Long = System.currentTimeMillis(),
  val durationSeconds: Int,
  val avgFps: Float,
  val minFps: Float,
  val maxFps: Float,
  val onePercentLowFps: Float,
  val avgFrameTimeMs: Float,
  val jitterMs: Float,
  val stuttersTotal: Int,
  val batteryStartTemp: Float,
  val batteryEndTemp: Float,
  val thermalStatusPeak: String,
  val deviceModel: String,
  val androidVersion: String,
  val notes: String
)

@Entity(tableName = "setting_backups")
data class SettingBackupEntity(
  @PrimaryKey val settingKey: String,
  val originalValue: String,
  val backupTimestamp: Long = System.currentTimeMillis(),
  val lastRestoredTimestamp: Long? = null
)
