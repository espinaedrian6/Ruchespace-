package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.ReportDao
import com.example.data.local.dao.SettingBackupDao
import com.example.data.local.entity.PerformanceReportEntity
import com.example.data.local.entity.SettingBackupEntity

@Database(
  entities = [PerformanceReportEntity::class, SettingBackupEntity::class],
  version = 1,
  exportSchema = false
)
abstract class RucheSpaceDatabase : RoomDatabase() {
  abstract fun reportDao(): ReportDao
  abstract fun settingBackupDao(): SettingBackupDao

  companion object {
    @Volatile
    private var INSTANCE: RucheSpaceDatabase? = null

    fun getInstance(context: Context): RucheSpaceDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          RucheSpaceDatabase::class.java,
          "ruchespace.db"
        ).fallbackToDestructiveMigration().build()
        INSTANCE = instance
        instance
      }
    }
  }
}
