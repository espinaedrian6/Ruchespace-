package com.example.data.model

data class CpuCoreInfo(
  val coreIndex: Int,
  val isOnline: Boolean,
  val currentFreqMhz: Int,
  val maxFreqMhz: Int
)

data class CpuInfo(
  val processorName: String,
  val socModel: String,
  val hardwareName: String,
  val supportedAbis: List<String>,
  val totalCores: Int,
  val activeCores: Int,
  val minFreqMhz: Int,
  val maxFreqMhz: Int,
  val coreDetails: List<CpuCoreInfo>,
  val governor: String
)

data class GpuInfo(
  val glVendor: String,
  val glRenderer: String,
  val glVersion: String,
  val vulkanSupported: Boolean,
  val vulkanApiVersion: String,
  val maxTextureSize: Int,
  val extensionsCount: Int
)

enum class ThermalStatusLevel(val code: Int, val title: String, val severityColor: Long) {
  NONE(0, "Normal / Cool", 0xFF10B981),
  LIGHT(1, "Light Warmth", 0xFF3B82F6),
  MODERATE(2, "Moderate Heating", 0xFFF59E0B),
  SEVERE(3, "Severe Throttling", 0xFFF97316),
  CRITICAL(4, "Critical Limit", 0xFFEF4444),
  EMERGENCY(5, "Emergency Cooling", 0xFFDC2626),
  SHUTDOWN(6, "Thermal Shutdown Imminent", 0xFF7F1D1D)
}

data class ThermalInfo(
  val statusLevel: ThermalStatusLevel,
  val thermalHeadroom: Float?, // 0.0 to 1.0+ (where 1.0 means throttling threshold is reached)
  val isThrottlingActive: Boolean,
  val diagnosticTip: String
)

data class BatteryTelemetry(
  val levelPercent: Int,
  val temperatureCelsius: Float,
  val voltageMv: Int,
  val isCharging: Boolean,
  val chargingStatus: String,
  val health: String,
  val powerWattageEstimate: Float
)

data class MemoryTelemetry(
  val totalRamMb: Long,
  val availableRamMb: Long,
  val usedRamPercent: Int,
  val isLowMemory: Boolean,
  val lowMemoryThresholdMb: Long,
  val totalStorageGb: Float,
  val freeStorageGb: Float
)

enum class BottleneckType(val title: String, val badgeColor: Long) {
  BALANCED("System Balanced", 0xFF10B981),
  HEAT_THROTTLING("Thermal Throttling", 0xFFEF4444),
  RAM_PRESSURE("Memory Saturation", 0xFFF59E0B),
  GPU_FILLRATE("GPU Fillrate Bound", 0xFF8B5CF6),
  CPU_BOUND("CPU Single-Thread Bound", 0xFF3B82F6),
  GAME_ENGINE_CAP("Game Engine Cap", 0xFF64748B)
}

data class BottleneckDiagnosis(
  val primaryBottleneck: BottleneckType,
  val confidenceScore: Int, // 0 - 100%
  val observations: List<String>,
  val actionableRemedy: String,
  val safeOptimizationNotice: String
)
