package com.example.data.model

data class DisplayResolutionMode(
  val id: Int,
  val width: Int,
  val height: Int,
  val refreshRate: Float,
  val isCurrent: Boolean,
  val isNative: Boolean
) {
  val resolutionLabel: String
    get() = "${width}x${height} @ ${String.format("%.0f", refreshRate)}Hz"
}

data class DisplayDeviceInfo(
  val currentWidth: Int,
  val currentHeight: Int,
  val densityDpi: Int,
  val densityScale: Float,
  val currentRefreshRate: Float,
  val supportedModes: List<DisplayResolutionMode>,
  val supportedRefreshRates: List<Float>,
  val hdrSupported: Boolean,
  val wideColorGamut: Boolean,
  val physicalSizeInches: Float
)

data class ResolutionScalingPreset(
  val id: String,
  val name: String,
  val scalePercent: Int,
  val targetWidth: Int,
  val targetHeight: Int,
  val targetDensityDpi: Int,
  val description: String,
  val expectedGpuRelief: String,
  val clarityImpact: String,
  val safetyNotice: String
)

data class SafeDisplayChangeState(
  val originalWidth: Int,
  val originalHeight: Int,
  val originalDensity: Int,
  val originalRefreshRate: Float,
  val newWidth: Int,
  val newHeight: Int,
  val newDensity: Int,
  val newRefreshRate: Float,
  val secondsRemaining: Int,
  val isPendingConfirmation: Boolean
)
