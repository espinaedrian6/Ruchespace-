package com.example.data.model

enum class GraphicsRecommendationLevel(val label: String, val description: String) {
  LOW("Low Graphics", "Prioritizes minimum frame drops, maximum battery life, and lowest thermal output"),
  BALANCED("Balanced", "Optimal compromise between 60 FPS fluidity and visual fidelity"),
  HIGH("High Quality", "Rich textures and shadows for flagship processors with active cooling"),
  CUSTOM("Custom", "Fine-tuned parameters matching user thermal and visual preferences")
}

data class GameGraphicsProfile(
  val id: String,
  val gameName: String,
  val packageName: String,
  val genre: String,
  val nativeFpsCap: String, // e.g. "60 / 90 / 120 FPS (Device dependent)"
  val recommendationLevel: GraphicsRecommendationLevel,
  val textureQuality: String,
  val shadowQuality: String,
  val antiAliasing: String,
  val effectsQuality: String,
  val renderResolutionPercent: String,
  val targetFpsSetting: String,
  val inGameInstructions: List<String>,
  val technicalNotes: String
)

val PRESET_GAME_GRAPHICS: List<GameGraphicsProfile> = listOf(
  GameGraphicsProfile(
    id = "genshin_impact",
    gameName = "Genshin Impact",
    packageName = "com.miHoYo.GenshinImpact",
    genre = "Open World Action RPG",
    nativeFpsCap = "30 / 45 / 60 FPS",
    recommendationLevel = GraphicsRecommendationLevel.BALANCED,
    textureQuality = "Medium",
    shadowQuality = "Low",
    antiAliasing = "TAA (or SMAA on high-tier)",
    effectsQuality = "Medium",
    renderResolutionPercent = "Medium (0.8x native)",
    targetFpsSetting = "60 FPS (with low motion blur)",
    inGameInstructions = listOf(
      "Open in-game Paimon Menu -> Settings -> Graphics",
      "Set 'Graphics Quality' to Custom",
      "Set 'Render Resolution' to Medium or High",
      "Set 'Shadow Quality' to Low (biggest thermal savings)",
      "Set 'Visual Effects' to Medium to prevent frame drops in Sumeru/Natlan combat"
    ),
    technicalNotes = "Android cannot override Unity render resolution from outside the APK without root Vulkan layer injection. Settings must be selected in the game's menu."
  ),
  GameGraphicsProfile(
    id = "pubg_mobile",
    gameName = "PUBG Mobile / BGMI",
    packageName = "com.tencent.ig",
    genre = "Battle Royale",
    nativeFpsCap = "60 / 90 / 120 FPS (Device allowlist)",
    recommendationLevel = GraphicsRecommendationLevel.LOW,
    textureQuality = "Smooth",
    shadowQuality = "Disabled",
    antiAliasing = "Disabled or 2x",
    effectsQuality = "Low",
    renderResolutionPercent = "100%",
    targetFpsSetting = "90 FPS or Extreme (60 FPS)",
    inGameInstructions = listOf(
      "Open Settings -> Graphics & Audio",
      "Select 'Smooth' graphics (never HD/HDR for competitive play)",
      "Select highest available Frame Rate ('90 FPS' or 'Extreme')",
      "Disable 'Auto-adjust graphics' so the game doesn't randomly downscale FPS",
      "Set Style to 'Colorful' or 'Soft' for enemy visibility"
    ),
    technicalNotes = "PUBG uses a server-side device whitelist for 90/120 FPS modes based on Build.MODEL. RucheSpace provides genuine refresh rate alignment so the panel doesn't tear."
  ),
  GameGraphicsProfile(
    id = "cod_mobile",
    gameName = "Call of Duty: Mobile",
    packageName = "com.activision.callofduty.shooter",
    genre = "First-Person Shooter",
    nativeFpsCap = "60 / 90 / 120 FPS",
    recommendationLevel = GraphicsRecommendationLevel.BALANCED,
    textureQuality = "Low / Medium",
    shadowQuality = "Real-time Shadows Off",
    antiAliasing = "Off",
    effectsQuality = "Medium",
    renderResolutionPercent = "Medium",
    targetFpsSetting = "Ultra (120 FPS in MP) or Max (60 FPS in BR)",
    inGameInstructions = listOf(
      "Open Settings -> Audio and Graphics",
      "Set 'Graphic Quality' to Low",
      "Set 'Frame Rate' to Ultra (120Hz) or Max (60Hz)",
      "Disable Bloom, Depth of Field, and Ragdoll physics",
      "Enable 'Anti-Aliasing' only if jagged edges distract during long-range gunfights"
    ),
    technicalNotes = "Ultra frame rate is locked to Multiplayer mode only in COD Mobile. BR mode caps at 60 or 90 FPS by game design."
  ),
  GameGraphicsProfile(
    id = "honkai_star_rail",
    gameName = "Honkai: Star Rail",
    packageName = "com.HoYoverse.hkrpgoversea",
    genre = "Turn-Based RPG",
    nativeFpsCap = "30 / 60 FPS",
    recommendationLevel = GraphicsRecommendationLevel.BALANCED,
    textureQuality = "High",
    shadowQuality = "Medium",
    antiAliasing = "TAA",
    effectsQuality = "Medium",
    renderResolutionPercent = "1.0x",
    targetFpsSetting = "60 FPS",
    inGameInstructions = listOf(
      "Open Phone Menu -> Settings -> Graphics",
      "Set FPS to 60",
      "Set Resolution to High",
      "Set Shadow Quality to Medium or Low to prevent Penacony lag",
      "Turn Light Quality to Medium"
    ),
    technicalNotes = "Turn-based combat generates high burst GPU load during Ultimate animations. Lowering reflection and bloom keeps frame-times consistent."
  ),
  GameGraphicsProfile(
    id = "minecraft",
    gameName = "Minecraft Bedrock",
    packageName = "com.mojang.minecraftpe",
    genre = "Sandbox / Survival",
    nativeFpsCap = "Uncapped / Matches Refresh Rate",
    recommendationLevel = GraphicsRecommendationLevel.BALANCED,
    textureQuality = "Standard",
    shadowQuality = "Fancy Graphics On",
    antiAliasing = "Texel Anti-Aliasing 1",
    effectsQuality = "Render Clouds Off",
    renderResolutionPercent = "Native",
    targetFpsSetting = "Render Distance 12 Chunks",
    inGameInstructions = listOf(
      "Open Settings -> Video",
      "Set Render Distance to 10-14 Chunks depending on RAM",
      "Toggle 'Fancy Leaves' and 'Render Clouds' to Off for +15 FPS",
      "Set Anti-Aliasing slider to 1 or 2"
    ),
    technicalNotes = "Minecraft natively syncs to display refresh rate on Android (V-Sync). Enabling 120Hz via RucheSpace directly allows 120 FPS rendering if chunks permit."
  ),
  GameGraphicsProfile(
    id = "asphalt_legends",
    gameName = "Asphalt Legends Unite",
    packageName = "com.gameloft.android.ANMP.GloftA9HM",
    genre = "Arcade Racing",
    nativeFpsCap = "60 FPS",
    recommendationLevel = GraphicsRecommendationLevel.HIGH,
    textureQuality = "Default",
    shadowQuality = "High",
    antiAliasing = "Default",
    effectsQuality = "High",
    renderResolutionPercent = "High",
    targetFpsSetting = "60 FPS Mode",
    inGameInstructions = listOf(
      "Open Game Settings -> Game Settings -> Sound & Display",
      "Change Visual Quality to '60 FPS' or 'Performance'",
      "Disable motion blur if eye strain occurs"
    ),
    technicalNotes = "Some device models require Gameloft server config files to unlock 60 FPS mode. Setting 60Hz mode in RucheSpace prevents frame pacing jitter."
  )
)
