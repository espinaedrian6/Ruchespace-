package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.RucheSpaceViewModel
import com.example.ui.components.CyberCard
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun CpuGpuCenterScreen(
  viewModel: RucheSpaceViewModel,
  modifier: Modifier = Modifier
) {
  val cpuInfo by viewModel.cpuInfo.collectAsStateWithLifecycle()
  val gpuInfo by viewModel.gpuInfo.collectAsStateWithLifecycle()
  val thermalInfo by viewModel.thermalInfo.collectAsStateWithLifecycle()
  val batteryTelemetry by viewModel.batteryTelemetry.collectAsStateWithLifecycle()
  val memoryTelemetry by viewModel.memoryTelemetry.collectAsStateWithLifecycle()
  val bottleneck by viewModel.bottleneck.collectAsStateWithLifecycle()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Bottleneck Guidance Engine Card (Feature 16)
    item {
      Spacer(modifier = Modifier.height(4.dp))
      val badgeColor = Color(bottleneck.primaryBottleneck.badgeColor)
      CyberCard(borderColor = badgeColor, glowAccent = badgeColor) {
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Bolt, contentDescription = null, tint = badgeColor)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "PERFORMANCE BOTTLENECK ENGINE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = TextPrimary
              )
            }

            Surface(
              shape = RoundedCornerShape(6.dp),
              color = badgeColor.copy(alpha = 0.15f)
            ) {
              Text(
                text = "${bottleneck.primaryBottleneck.title} (${bottleneck.confidenceScore}%)",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = badgeColor,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Text(
            text = "EVIDENCE DETECTED:",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted,
            letterSpacing = 0.5.sp
          )
          Spacer(modifier = Modifier.height(4.dp))
          bottleneck.observations.forEach { obs ->
            Row(modifier = Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
              Box(modifier = Modifier.size(5.dp).clip(CircleShape).background(badgeColor))
              Spacer(modifier = Modifier.width(8.dp))
              Text(text = obs, fontSize = 12.sp, color = TextSecondary)
            }
          }

          Spacer(modifier = Modifier.height(10.dp))
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = DarkSurfaceElevated,
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text(
                text = "ACTIONABLE RECOMMENDATION:",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = CyberCyan
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = bottleneck.actionableRemedy,
                fontSize = 12.sp,
                color = TextPrimary,
                lineHeight = 16.sp
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = bottleneck.safeOptimizationNotice,
            fontSize = 11.sp,
            color = TextMuted
          )
        }
      }
    }

    // Thermal Status & Battery Telemetry
    item {
      CyberCard {
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Thermostat, contentDescription = null, tint = AmberWarning)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "THERMAL & POWER TELEMETRY",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = TextPrimary
              )
            }

            Surface(
              shape = RoundedCornerShape(6.dp),
              color = Color(thermalInfo.statusLevel.severityColor).copy(alpha = 0.15f)
            ) {
              Text(
                text = thermalInfo.statusLevel.title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(thermalInfo.statusLevel.severityColor),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text("BATTERY TEMPERATURE", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold)
              Text(
                text = "${String.format("%.1f", batteryTelemetry.temperatureCelsius)} °C",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = if (batteryTelemetry.temperatureCelsius > 40f) AmberWarning else TextPrimary,
                fontFamily = FontFamily.Monospace
              )
              Text("Safe limit: < 42°C", fontSize = 10.sp, color = TextSecondary)
            }

            Column {
              Text("BATTERY LEVEL", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold)
              Text(
                text = "${batteryTelemetry.levelPercent}%",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = EmeraldGlow,
                fontFamily = FontFamily.Monospace
              )
              Text(batteryTelemetry.chargingStatus, fontSize = 10.sp, color = TextSecondary)
            }

            Column {
              Text("VOLTAGE / DRAW", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold)
              Text(
                text = "${batteryTelemetry.voltageMv} mV",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = CyberCyan,
                fontFamily = FontFamily.Monospace
              )
              Text("Health: ${batteryTelemetry.health}", fontSize = 10.sp, color = TextSecondary)
            }
          }

          Spacer(modifier = Modifier.height(10.dp))
          Text(
            text = thermalInfo.diagnosticTip,
            fontSize = 11.sp,
            color = TextSecondary,
            lineHeight = 16.sp
          )
        }
      }
    }

    // CPU Model & Core Frequency Telemetry (Feature 16)
    item {
      CyberCard {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Memory, contentDescription = null, tint = CyberCyan)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "CPU / SOC ARCHITECTURE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = CyberCyan
              )
              Text(
                text = "${cpuInfo.socModel} (${cpuInfo.processorName})",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = "Total Cores: ${cpuInfo.totalCores} (${cpuInfo.activeCores} Online) • Frequency: ${cpuInfo.minFreqMhz}MHz - ${cpuInfo.maxFreqMhz}MHz • Governor: ${cpuInfo.governor}",
            fontSize = 11.sp,
            color = TextSecondary
          )

          Spacer(modifier = Modifier.height(12.dp))

          Text(
            text = "INDIVIDUAL CORE CLUSTER ACTIVITY",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted,
            letterSpacing = 0.5.sp
          )
          Spacer(modifier = Modifier.height(6.dp))

          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            cpuInfo.coreDetails.forEach { core ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(6.dp))
                  .background(DarkSurfaceElevated)
                  .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "Core #${core.coreIndex}",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (core.isOnline) TextPrimary else TextMuted
                )
                Text(
                  text = if (core.isOnline) "${core.currentFreqMhz} MHz" else "Offline (Power Saved)",
                  fontSize = 12.sp,
                  color = if (core.isOnline) CyberCyan else TextMuted,
                  fontFamily = FontFamily.Monospace
                )
              }
            }
          }
        }
      }
    }

    // GPU Renderer & Vulkan Hardware Specs (Feature 16)
    item {
      CyberCard {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Speed, contentDescription = null, tint = NeonViolet)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "GPU RENDERER & GRAPHICS STACK",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = NeonViolet
              )
              Text(
                text = gpuInfo.glRenderer,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          GpuSpecRow("GPU Vendor", gpuInfo.glVendor)
          GpuSpecRow("OpenGL ES Version", gpuInfo.glVersion)
          GpuSpecRow("Vulkan Graphics API", gpuInfo.vulkanApiVersion)
          GpuSpecRow("Max Texture Dimension", "${gpuInfo.maxTextureSize} x ${gpuInfo.maxTextureSize} px")
          GpuSpecRow("Supported GL Extensions", "${gpuInfo.extensionsCount} extensions certified")
        }
      }
    }

    // Overclocking & Safety Boundary Notice (Feature 16/20)
    item {
      CyberCard(borderColor = DarkBorder) {
        Row(verticalAlignment = Alignment.Top) {
          Icon(Icons.Default.Security, contentDescription = null, tint = EmeraldGlow, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "HARDWARE INTEGRITY GUARANTEE",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = EmeraldGlow
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "RucheSpace never claims to overclock CPU or GPU frequencies beyond factory specifications without authorized hardware interfaces, and never attempts to bypass kernel thermal safety throttling. Doing so would risk permanent silicon damage and battery swelling.",
              fontSize = 11.sp,
              color = TextSecondary,
              lineHeight = 16.sp
            )
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}

@Composable
private fun GpuSpecRow(label: String, value: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(text = label, fontSize = 12.sp, color = TextSecondary)
    Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
  }
}
