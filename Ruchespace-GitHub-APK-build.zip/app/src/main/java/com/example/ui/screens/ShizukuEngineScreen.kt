package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ALLOWLISTED_OPERATIONS
import com.example.data.model.KNOWN_MANUFACTURER_RESTRICTIONS
import com.example.ui.RucheSpaceViewModel
import com.example.ui.components.CyberCard
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ShizukuEngineScreen(
  viewModel: RucheSpaceViewModel,
  modifier: Modifier = Modifier
) {
  val shizukuState by viewModel.shizukuController.shizukuState.collectAsStateWithLifecycle()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Shizuku Binder Connection Status Card using reusable indicator
    item {
      Spacer(modifier = Modifier.height(4.dp))
      com.example.ui.components.ShizukuPermissionStatusIndicator(
        shizukuState = shizukuState,
        onRequestPermission = { viewModel.requestShizukuPermission() },
        onRefresh = { viewModel.refreshShizuku() },
        onTestIpcEcho = { viewModel.testShizukuEcho() }
      )
    }

    // Educational Card: Shizuku != Root
    item {
      CyberCard(borderColor = NeonViolet.copy(alpha = 0.4f)) {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Security, contentDescription = null, tint = NeonViolet)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "TECHNICAL ARCHITECTURE: SHIZUKU IS NOT ROOT",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          }

          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "• Shizuku runs as standard Android ADB shell user (UID 2000). It does NOT possess root privileges (UID 0).\n• It cannot modify system read-only partitions, flash kernels, bypass SELinux, or touch other apps' private files.\n• It is strictly used in RucheSpace to invoke documented ADB shell settings commands (e.g. Settings.System peak_refresh_rate) without requiring a PC connection.",
            fontSize = 12.sp,
            color = TextSecondary,
            lineHeight = 17.sp
          )
        }
      }
    }

    // Strict Allowlist Audit (Feature 18)
    item {
      Text(
        text = "STRICT OPERATION ALLOWLIST (AUDITED)",
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        color = TextMuted,
        modifier = Modifier.padding(start = 4.dp)
      )
      Spacer(modifier = Modifier.height(4.dp))

      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ALLOWLISTED_OPERATIONS.forEach { op ->
          CyberCard {
            Column {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = op.title,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary
                )
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = EmeraldGlow.copy(alpha = 0.15f)
                ) {
                  Text(
                    text = "ALLOWLISTED",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldGlow,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }

              Spacer(modifier = Modifier.height(4.dp))
              Text(text = op.description, fontSize = 11.sp, color = TextSecondary)

              Spacer(modifier = Modifier.height(6.dp))
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = DarkSurfaceElevated,
                modifier = Modifier.fillMaxWidth()
              ) {
                Text(
                  text = op.commandPattern,
                  fontSize = 11.sp,
                  color = CyberCyan,
                  fontFamily = FontFamily.Monospace,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }

              Spacer(modifier = Modifier.height(4.dp))
              Text(text = "Vendor Note: ${op.vendorSupportNote}", fontSize = 10.sp, color = TextMuted)
            }
          }
        }
      }
    }

    // Known Manufacturer Restrictions Guide (Feature 18)
    item {
      Text(
        text = "MANUFACTURER RESTRICTIONS & REMEDIES",
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        color = TextMuted,
        modifier = Modifier.padding(start = 4.dp)
      )
      Spacer(modifier = Modifier.height(4.dp))

      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        KNOWN_MANUFACTURER_RESTRICTIONS.forEach { info ->
          CyberCard(borderColor = AmberWarning.copy(alpha = 0.3f)) {
            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = info.manufacturer,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary
                )
              }

              Spacer(modifier = Modifier.height(4.dp))
              Text(text = info.restrictionName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AmberWarning)

              Spacer(modifier = Modifier.height(4.dp))
              Text(text = "Symptom: ${info.symptoms}", fontSize = 11.sp, color = TextSecondary)

              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Remedy: ${info.userActionRequired}",
                fontSize = 11.sp,
                color = EmeraldGlow,
                lineHeight = 15.sp
              )
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}
