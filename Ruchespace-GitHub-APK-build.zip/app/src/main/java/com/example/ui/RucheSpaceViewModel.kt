package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.hardware.DisplayManagerHelper
import com.example.data.hardware.HardwareInspector
import com.example.data.hardware.ProfileManager
import com.example.data.hardware.RealFpsTracker
import com.example.data.hardware.ShizukuController
import com.example.data.local.RucheSpaceDatabase
import com.example.data.local.RucheSpaceRepository
import com.example.data.local.entity.PerformanceReportEntity
import com.example.data.model.BatteryTelemetry
import com.example.data.model.BottleneckDiagnosis
import com.example.data.model.CpuInfo
import com.example.data.model.DEFAULT_GAMING_PROFILES
import com.example.data.model.DisplayDeviceInfo
import com.example.data.model.GameGraphicsProfile
import com.example.data.model.GamingProfileConfig
import com.example.data.model.GpuInfo
import com.example.data.model.LiveBenchmarkSession
import com.example.data.model.MemoryTelemetry
import com.example.data.model.PRESET_GAME_GRAPHICS
import com.example.data.model.ProfileApplicationReport
import com.example.data.model.ProfileId
import com.example.data.model.ResolutionScalingPreset
import com.example.data.model.SYSTEM_SAFETY_CAPABILITIES
import com.example.data.model.SafeDisplayChangeState
import com.example.data.model.SafetyCapability
import com.example.data.model.ShizukuOperationId
import com.example.data.model.ThermalInfo
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class RucheSpaceViewModel(application: Application) : AndroidViewModel(application) {

  private val database = RucheSpaceDatabase.getInstance(application)
  val repository = RucheSpaceRepository(database.reportDao(), database.settingBackupDao())

  val displayHelper = DisplayManagerHelper(application)
  val hardwareInspector = HardwareInspector(application)
  val fpsTracker = RealFpsTracker()
  val shizukuController = ShizukuController(application)
  val profileManager = ProfileManager(application, repository, shizukuController)

  // Hardware State
  private val _displayInfo = MutableStateFlow(displayHelper.getDisplayDeviceInfo())
  val displayInfo: StateFlow<DisplayDeviceInfo> = _displayInfo.asStateFlow()

  private val _cpuInfo = MutableStateFlow(hardwareInspector.detectCpuInfo())
  val cpuInfo: StateFlow<CpuInfo> = _cpuInfo.asStateFlow()

  private val _gpuInfo = MutableStateFlow(hardwareInspector.detectGpuInfo())
  val gpuInfo: StateFlow<GpuInfo> = _gpuInfo.asStateFlow()

  private val _thermalInfo = MutableStateFlow(hardwareInspector.detectThermalInfo())
  val thermalInfo: StateFlow<ThermalInfo> = _thermalInfo.asStateFlow()

  private val _batteryTelemetry = MutableStateFlow(hardwareInspector.detectBatteryTelemetry())
  val batteryTelemetry: StateFlow<BatteryTelemetry> = _batteryTelemetry.asStateFlow()

  private val _memoryTelemetry = MutableStateFlow(hardwareInspector.detectMemoryTelemetry())
  val memoryTelemetry: StateFlow<MemoryTelemetry> = _memoryTelemetry.asStateFlow()

  private val _bottleneck = MutableStateFlow(
    hardwareInspector.diagnoseBottlenecks(
      _thermalInfo.value,
      _batteryTelemetry.value,
      _memoryTelemetry.value,
      0f,
      60
    )
  )
  val bottleneck: StateFlow<BottleneckDiagnosis> = _bottleneck.asStateFlow()

  // Selected Controls
  private val _selectedFpsTarget = MutableStateFlow(60)
  val selectedFpsTarget: StateFlow<Int> = _selectedFpsTarget.asStateFlow()

  val fpsMetrics = fpsTracker.metrics

  // Game Graphics Profiles
  private val _gamesList = MutableStateFlow(PRESET_GAME_GRAPHICS)
  val gamesList: StateFlow<List<GameGraphicsProfile>> = _gamesList.asStateFlow()

  private val _selectedGame = MutableStateFlow<GameGraphicsProfile?>(PRESET_GAME_GRAPHICS.first())
  val selectedGame: StateFlow<GameGraphicsProfile?> = _selectedGame.asStateFlow()

  // Gaming Profiles
  val gamingProfiles = DEFAULT_GAMING_PROFILES
  val activeProfileId = profileManager.activeProfileId
  val lastProfileReport = profileManager.lastReport

  // Resolution Scaling & Auto Revert
  val resolutionPresets = displayHelper.getResolutionScalingPresets(_displayInfo.value)
  private val _safeChangeState = MutableStateFlow<SafeDisplayChangeState?>(null)
  val safeChangeState: StateFlow<SafeDisplayChangeState?> = _safeChangeState.asStateFlow()
  private var autoRevertJob: Job? = null

  // Live Benchmark Session
  private val _benchmarkSession = MutableStateFlow<LiveBenchmarkSession?>(null)
  val benchmarkSession: StateFlow<LiveBenchmarkSession?> = _benchmarkSession.asStateFlow()
  private var benchmarkJob: Job? = null

  // Room Stored Reports
  val savedReports: StateFlow<List<PerformanceReportEntity>> = repository.allReports
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Safety Matrix
  val safetyCapabilities: List<SafetyCapability> = SYSTEM_SAFETY_CAPABILITIES

  // Status message
  private val _uiNotice = MutableStateFlow<String?>(null)
  val uiNotice: StateFlow<String?> = _uiNotice.asStateFlow()

  init {
    fpsTracker.startTracking()
    startHardwarePolling()
  }

  private fun startHardwarePolling() {
    viewModelScope.launch {
      while (true) {
        delay(2000)
        _thermalInfo.value = hardwareInspector.detectThermalInfo()
        _batteryTelemetry.value = hardwareInspector.detectBatteryTelemetry()
        _memoryTelemetry.value = hardwareInspector.detectMemoryTelemetry()
        _bottleneck.value = hardwareInspector.diagnoseBottlenecks(
          _thermalInfo.value,
          _batteryTelemetry.value,
          _memoryTelemetry.value,
          fpsMetrics.value.rollingFps,
          _selectedFpsTarget.value
        )
      }
    }
  }

  fun refreshDisplayInfo() {
    _displayInfo.value = displayHelper.getDisplayDeviceInfo()
  }

  fun selectFpsTarget(target: Int) {
    _selectedFpsTarget.value = target
  }

  fun selectGame(game: GameGraphicsProfile) {
    _selectedGame.value = game
  }

  fun clearUiNotice() {
    _uiNotice.value = null
  }

  // Refresh Rate Controller
  fun setPreferredRefreshRate(rate: Float) {
    viewModelScope.launch {
      val isShizuku = shizukuController.shizukuState.value.let { it.isBinderAlive && it.isPermissionGranted }
      if (isShizuku) {
        val result = shizukuController.executeAllowlistedOperation(
          ShizukuOperationId.SET_PEAK_REFRESH_RATE,
          rate.toString()
        )
        if (result.isSuccess) {
          _uiNotice.value = "System peak refresh rate successfully locked to ${rate.toInt()}Hz via Shizuku."
        } else {
          _uiNotice.value = "Shizuku notice: ${result.securityNotice}"
        }
      } else {
        _uiNotice.value = "Window target rate set to ${rate.toInt()}Hz. For system-wide lock, connect Shizuku."
      }
      refreshDisplayInfo()
    }
  }

  fun resetRefreshRateDefaults() {
    viewModelScope.launch {
      val isShizuku = shizukuController.shizukuState.value.let { it.isBinderAlive && it.isPermissionGranted }
      if (isShizuku) {
        shizukuController.executeAllowlistedOperation(ShizukuOperationId.RESET_REFRESH_RATE)
        _uiNotice.value = "System refresh rate reset to factory adaptive defaults."
      } else {
        _uiNotice.value = "Window refresh rate restored to default."
      }
      refreshDisplayInfo()
    }
  }

  // Safe Resolution / Density Scaling with 10s auto-revert countdown
  fun applyResolutionPresetWithSafeTimer(preset: ResolutionScalingPreset) {
    val current = _displayInfo.value
    autoRevertJob?.cancel()

    val pendingState = SafeDisplayChangeState(
      originalWidth = current.currentWidth,
      originalHeight = current.currentHeight,
      originalDensity = current.densityDpi,
      originalRefreshRate = current.currentRefreshRate,
      newWidth = preset.targetWidth,
      newHeight = preset.targetHeight,
      newDensity = preset.targetDensityDpi,
      newRefreshRate = current.currentRefreshRate,
      secondsRemaining = 10,
      isPendingConfirmation = true
    )
    _safeChangeState.value = pendingState

    // If Shizuku is connected, apply temporary density
    viewModelScope.launch {
      if (shizukuController.shizukuState.value.isPermissionGranted) {
        shizukuController.executeAllowlistedOperation(
          ShizukuOperationId.SET_DISPLAY_DENSITY,
          preset.targetDensityDpi.toString()
        )
      }
    }

    // Launch countdown ticker
    autoRevertJob = viewModelScope.launch {
      for (sec in 9 downTo 0) {
        delay(1000)
        val curState = _safeChangeState.value
        if (curState != null && curState.isPendingConfirmation) {
          _safeChangeState.value = curState.copy(secondsRemaining = sec)
        } else {
          break
        }
      }
      // If timer expires without confirmation, auto-revert!
      if (_safeChangeState.value?.isPendingConfirmation == true) {
        revertResolutionImmediately()
      }
    }
  }

  fun confirmKeepResolutionChanges() {
    autoRevertJob?.cancel()
    _safeChangeState.value = null
    _uiNotice.value = "Display scaling confirmed and saved."
    refreshDisplayInfo()
  }

  fun revertResolutionImmediately() {
    autoRevertJob?.cancel()
    val state = _safeChangeState.value
    _safeChangeState.value = null

    viewModelScope.launch {
      if (shizukuController.shizukuState.value.isPermissionGranted) {
        shizukuController.executeAllowlistedOperation(ShizukuOperationId.RESET_DISPLAY_DENSITY)
      }
      _uiNotice.value = "Display scaling reverted back to original native values."
      refreshDisplayInfo()
    }
  }

  // Gaming Profiles
  fun applyProfile(profile: GamingProfileConfig) {
    viewModelScope.launch {
      val report = profileManager.applyProfile(profile, _displayInfo.value)
      _selectedFpsTarget.value = profile.fpsTargetCap
      _uiNotice.value = "Profile '${profile.name}' applied. ${report.changesApplied.firstOrNull() ?: ""}"
      refreshDisplayInfo()
    }
  }

  fun undoActiveProfile() {
    viewModelScope.launch {
      val report = profileManager.undoAndRestoreDefaults(_displayInfo.value)
      _selectedFpsTarget.value = 60
      _uiNotice.value = report.activeNotice
      refreshDisplayInfo()
    }
  }

  // Shizuku Actions
  fun requestShizukuPermission() {
    shizukuController.requestPermission()
  }

  fun refreshShizuku() {
    shizukuController.refreshShizukuStatus()
  }

  fun testShizukuEcho() {
    viewModelScope.launch {
      val result = shizukuController.executeAllowlistedOperation(ShizukuOperationId.TEST_BINDER_ECHO)
      _uiNotice.value = if (result.isSuccess) "Shizuku IPC OK: ${result.output}" else "Shizuku Error: ${result.errorOutput}"
    }
  }

  // Performance Test Center
  fun startLiveBenchmark(testName: String = "Session Benchmark") {
    if (_benchmarkSession.value?.isRunning == true) return
    val initialBattery = _batteryTelemetry.value.temperatureCelsius

    _benchmarkSession.value = LiveBenchmarkSession(
      sessionName = testName,
      profileName = profileManager.activeProfileId.value.displayName,
      isRunning = true,
      elapsedSeconds = 0,
      currentFps = fpsMetrics.value.rollingFps,
      averageFps = fpsMetrics.value.rollingFps,
      minFps = fpsMetrics.value.rollingFps,
      maxFps = fpsMetrics.value.rollingFps,
      onePercentLowFps = fpsMetrics.value.onePercentLowFps,
      zeroPointOnePercentLowFps = fpsMetrics.value.zeroPointOnePercentLowFps,
      currentFrameTimeMs = fpsMetrics.value.currentFrameTimeMs,
      averageFrameTimeMs = fpsMetrics.value.avgFrameTimeMs,
      jitterVarianceMs = fpsMetrics.value.frameTimeJitterMs,
      totalJankFrames = 0,
      startBatteryTempC = initialBattery,
      currentBatteryTempC = initialBattery,
      peakThermalStatus = _thermalInfo.value.statusLevel.title
    )

    val fpsSamples = mutableListOf<Float>()

    benchmarkJob = viewModelScope.launch {
      while (_benchmarkSession.value?.isRunning == true) {
        delay(1000)
        val curSession = _benchmarkSession.value ?: break
        val currentFps = fpsMetrics.value.rollingFps
        if (currentFps > 0) fpsSamples.add(currentFps)

        val avgFps = if (fpsSamples.isNotEmpty()) fpsSamples.average().toFloat() else currentFps
        val minFps = if (fpsSamples.isNotEmpty()) fpsSamples.minOrNull() ?: currentFps else currentFps
        val maxFps = if (fpsSamples.isNotEmpty()) fpsSamples.maxOrNull() ?: currentFps else currentFps

        _benchmarkSession.value = curSession.copy(
          elapsedSeconds = curSession.elapsedSeconds + 1,
          currentFps = currentFps,
          averageFps = avgFps,
          minFps = minFps,
          maxFps = maxFps,
          onePercentLowFps = fpsMetrics.value.onePercentLowFps,
          zeroPointOnePercentLowFps = fpsMetrics.value.zeroPointOnePercentLowFps,
          currentFrameTimeMs = fpsMetrics.value.currentFrameTimeMs,
          averageFrameTimeMs = fpsMetrics.value.avgFrameTimeMs,
          jitterVarianceMs = fpsMetrics.value.frameTimeJitterMs,
          totalJankFrames = fpsMetrics.value.jankFramesCount,
          currentBatteryTempC = _batteryTelemetry.value.temperatureCelsius,
          peakThermalStatus = _thermalInfo.value.statusLevel.title,
          recentFrameTimes = fpsMetrics.value.frameHistoryMs,
          recentFpsPoints = fpsMetrics.value.fpsHistory
        )
      }
    }
  }

  fun stopAndSaveBenchmark() {
    benchmarkJob?.cancel()
    val session = _benchmarkSession.value ?: return

    viewModelScope.launch {
      val entity = PerformanceReportEntity(
        testName = session.sessionName,
        profileName = session.profileName,
        timestamp = System.currentTimeMillis(),
        durationSeconds = session.elapsedSeconds,
        avgFps = session.averageFps,
        minFps = session.minFps,
        maxFps = session.maxFps,
        onePercentLowFps = session.onePercentLowFps,
        avgFrameTimeMs = session.averageFrameTimeMs,
        jitterMs = session.jitterVarianceMs,
        stuttersTotal = session.totalJankFrames,
        batteryStartTemp = session.startBatteryTempC,
        batteryEndTemp = session.currentBatteryTempC,
        thermalStatusPeak = session.peakThermalStatus,
        deviceModel = "${android.os.Build.MANUFACTURER.uppercase()} ${android.os.Build.MODEL}",
        androidVersion = "Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})",
        notes = "Genuine Choreographer hardware frame timing report."
      )
      repository.saveReport(entity)
      _benchmarkSession.value = session.copy(isRunning = false)
      _uiNotice.value = "Performance report saved to local database (Avg: ${String.format("%.1f", session.averageFps)} FPS, 1% Low: ${String.format("%.1f", session.onePercentLowFps)} FPS)."
    }
  }

  fun deleteReport(id: Long) {
    viewModelScope.launch {
      repository.deleteReport(id)
    }
  }

  override fun onCleared() {
    super.onCleared()
    fpsTracker.stopTracking()
    shizukuController.unregister()
    autoRevertJob?.cancel()
    benchmarkJob?.cancel()
  }
}
