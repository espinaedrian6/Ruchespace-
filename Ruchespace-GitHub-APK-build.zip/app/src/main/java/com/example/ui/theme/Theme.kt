package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
  primary = CyberCyan,
  onPrimary = DarkVoid,
  primaryContainer = DarkSurfaceElevated,
  onPrimaryContainer = CyberCyan,
  secondary = NeonViolet,
  onSecondary = Color.White,
  secondaryContainer = DarkSurfaceElevated,
  onSecondaryContainer = NeonViolet,
  tertiary = EmeraldGlow,
  onTertiary = DarkVoid,
  background = DarkVoid,
  onBackground = TextPrimary,
  surface = DarkSurface,
  onSurface = TextPrimary,
  surfaceVariant = DarkSurfaceElevated,
  onSurfaceVariant = TextSecondary,
  outline = DarkBorder,
  outlineVariant = DarkBorderGlow,
  error = CrimsonAlert,
  onError = Color.White
)

private val LightColorScheme = DarkColorScheme // RucheSpace is an immersive high-tech dark theme application

@Composable
fun RucheSpaceTheme(
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = DarkColorScheme,
    typography = Typography,
    content = content
  )
}
