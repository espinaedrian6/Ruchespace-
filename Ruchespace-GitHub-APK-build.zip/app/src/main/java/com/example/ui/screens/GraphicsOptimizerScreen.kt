package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.GameGraphicsProfile
import com.example.data.model.ResolutionScalingPreset
import com.example.ui.RucheSpaceViewModel
import com.example.ui.components.AutoRevertDialog
import com.example.ui.components.CyberCard
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkBorderGlow
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun GraphicsOptimizerScreen(
  viewModel: RucheSpaceViewModel,
  modifier: Modifier = Modifier
) {
  val displayInfo by viewModel.displayInfo.collectAsStateWithLifecycle()
  val gamesList by viewModel.gamesList.collectAsStateWithLifecycle()
  val selectedGame by viewModel.selectedGame.collectAsStateWithLifecycle()
  val safeChangeState by viewModel.safeChangeState.collectAsStateWithLifecycle()
  val shizukuState by viewModel.shizukuController.shizukuState.collectAsStateWithLifecycle()

  var selectedPresetForPreview by remember { mutableStateOf<ResolutionScalingPreset?>(null) }

  // Auto Revert Dialog for safety
  safeChangeState?.let { state ->
    if (state.isPendingConfirmation) {
      AutoRevertDialog(
        title = "Display Scaling Safety Test",
        message = "Testing scaled density (${state.newDensity} DPI). Ensure text and buttons remain clearly visible and accessible.",
        remainingSeconds = state.secondsRemaining,
        onConfirmKeep = { viewModel.confirmKeepResolutionChanges() },
        onRevertNow = { viewModel.revertResolutionImmediately() }
      )
    }
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Current Display Hardware Resolution Header
    item {
      Spacer(modifier = Modifier.height(4.dp))
      CyberCard(glowAccent = CyberCyan) {
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "DISPLAY HARDWARE DETECTED",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = CyberCyan
              )
              Text(
                text = "${displayInfo.currentWidth} x ${displayInfo.currentHeight}",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TextPrimary
              )
            }

            Surface(
              shape = RoundedCornerShape(8.dp),
              color = DarkSurfaceElevated,
              border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
            ) {
              Text(
                text = "${displayInfo.densityDpi} DPI (${String.format("%.1f", displayInfo.densityScale)}x)",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = NeonViolet,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = "Physical: ~${String.format("%.1f", displayInfo.physicalSizeInches)}\" AMOLED/LCD • Refresh Rate: ${displayInfo.currentRefreshRate.toInt()}Hz • HDR: ${if (displayInfo.hdrSupported) "Supported" else "SDR"}",
            fontSize = 12.sp,
            color = TextSecondary
          )

          Spacer(modifier = Modifier.height(12.dp))

          // Supported Hardware Display Modes
          Text(
            text = "SUPPORTED DISPLAY MODES (${displayInfo.supportedModes.size} MODES)",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted,
            letterSpacing = 0.5.sp
          )
          Spacer(modifier = Modifier.height(6.dp))
          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            items(displayInfo.supportedModes) { mode ->
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (mode.isCurrent) CyberCyan.copy(alpha = 0.15f) else DarkSurfaceElevated,
                border = androidx.compose.foundation.BorderStroke(
                  1.dp,
                  if (mode.isCurrent) CyberCyan else DarkBorder
                )
              ) {
                Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                  Text(
                    text = "${mode.width}x${mode.height}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (mode.isCurrent) CyberCyan else TextPrimary,
                    fontFamily = FontFamily.Monospace
                  )
                  Text(
                    text = "${mode.refreshRate.toInt()}Hz ${if (mode.isCurrent) "(Active)" else ""}",
                    fontSize = 10.sp,
                    color = if (mode.isCurrent) EmeraldGlow else TextSecondary
                  )
                }
              }
            }
          }
        }
      }
    }

    // Educational Technical Truth Banner
    item {
      CyberCard(borderColor = NeonViolet.copy(alpha = 0.3f)) {
        Row(verticalAlignment = Alignment.Top) {
          Icon(Icons.Default.Info, contentDescription = null, tint = NeonViolet, modifier = Modifier.size(22.dp))
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "TECHNICAL FACT: ANDROID SANDBOX RULES",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Android OS enforces strict SELinux app sandboxing: no external app can magically change internal texture quality or shadow resolution inside another game without modifying the game's internal files or APK. RucheSpace provides validated in-game setup guides and safe system scaling.",
              fontSize = 12.sp,
              color = TextSecondary,
              lineHeight = 17.sp
            )
          }
        }
      }
    }

    // Resolution Scaling Presets (Feature 15)
    item {
      Text(
        text = "RESOLUTION & PIXEL SCALING (SAFE PRESETS)",
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        color = TextMuted,
        modifier = Modifier.padding(start = 4.dp)
      )
      Spacer(modifier = Modifier.height(6.dp))

      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        viewModel.resolutionPresets.forEach { preset ->
          val isCurrent = displayInfo.currentWidth == preset.targetWidth && displayInfo.currentHeight == preset.targetHeight

          CyberCard(
            borderColor = if (isCurrent) CyberCyan else DarkBorder,
            glowAccent = if (isCurrent) CyberCyan else null
          ) {
            Column {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = preset.name,
                      fontSize = 15.sp,
                      fontWeight = FontWeight.Bold,
                      color = TextPrimary
                    )
                    if (isCurrent) {
                      Spacer(modifier = Modifier.width(8.dp))
                      Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = EmeraldGlow.copy(alpha = 0.2f)
                      ) {
                        Text(
                          text = "ACTIVE",
                          fontSize = 10.sp,
                          fontWeight = FontWeight.Bold,
                          color = EmeraldGlow,
                          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                      }
                    }
                  }
                  Text(
                    text = "${preset.targetWidth} x ${preset.targetHeight} • Density: ~${preset.targetDensityDpi} DPI",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    color = CyberCyan
                  )
                }

                if (!isCurrent) {
                  Button(
                    onClick = {
                      selectedPresetForPreview = preset
                      viewModel.applyResolutionPresetWithSafeTimer(preset)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                    modifier = Modifier.height(34.dp).testTag("apply_preset_${preset.scalePercent}")
                  ) {
                    Text("Apply (10s Test)", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                  }
                } else {
                  OutlinedButton(
                    onClick = { viewModel.revertResolutionImmediately() },
                    modifier = Modifier.height(34.dp).testTag("reset_resolution_button")
                  ) {
                    Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(14.dp), tint = TextSecondary)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Restore", fontSize = 11.sp, color = TextSecondary)
                  }
                }
              }

              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = preset.description,
                fontSize = 12.sp,
                color = TextSecondary
              )

              Spacer(modifier = Modifier.height(6.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = "GPU Relief: ${preset.expectedGpuRelief}",
                  fontSize = 11.sp,
                  color = EmeraldGlow
                )
                Text(
                  text = preset.clarityImpact,
                  fontSize = 11.sp,
                  color = TextMuted
                )
              }
            }
          }
        }
      }
    }

    // Individual Game Graphics Recommendations (Feature 12)
    item {
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = "GAME GRAPHICS OPTIMIZER & IN-GAME GUIDES",
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        color = TextMuted,
        modifier = Modifier.padding(start = 4.dp)
      )
      Spacer(modifier = Modifier.height(6.dp))

      // Game selector horizontal chips
      LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(gamesList) { game ->
          val isSelected = selectedGame?.id == game.id
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (isSelected) NeonViolet.copy(alpha = 0.2f) else DarkSurfaceElevated,
            border = androidx.compose.foundation.BorderStroke(
              1.dp,
              if (isSelected) NeonViolet else DarkBorder
            ),
            onClick = { viewModel.selectGame(game) },
            modifier = Modifier.testTag("game_chip_${game.id}")
          ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
              Text(
                text = game.gameName,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) NeonViolet else TextPrimary
              )
              Text(
                text = game.genre,
                fontSize = 10.sp,
                color = TextMuted
              )
            }
          }
        }
      }
    }

    // Selected Game Card Detail
    selectedGame?.let { game ->
      item {
        CyberCard(glowAccent = NeonViolet) {
          Column {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = game.gameName,
                  fontSize = 18.sp,
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary
                )
                Text(
                  text = "Native Engine Limits: ${game.nativeFpsCap}",
                  fontSize = 12.sp,
                  color = EmeraldGlow
                )
              }

              Surface(
                shape = RoundedCornerShape(6.dp),
                color = NeonViolet.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonViolet.copy(alpha = 0.4f))
              ) {
                Text(
                  text = game.recommendationLevel.label,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = NeonViolet,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
              text = "RECOMMENDED SETTINGS CONFIGURATION",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = TextMuted,
              letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            SettingParamRow("Texture Quality", game.textureQuality)
            SettingParamRow("Shadow Quality", game.shadowQuality)
            SettingParamRow("Anti-Aliasing", game.antiAliasing)
            SettingParamRow("Visual Effects", game.effectsQuality)
            SettingParamRow("Render Resolution", game.renderResolutionPercent)
            SettingParamRow("Target Frame Rate", game.targetFpsSetting)

            Spacer(modifier = Modifier.height(14.dp))

            Text(
              text = "IN-GAME SETUP INSTRUCTIONS (MUST BE SET IN GAME)",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = CyberCyan,
              letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            game.inGameInstructions.forEachIndexed { idx, step ->
              Row(
                modifier = Modifier.padding(vertical = 3.dp),
                verticalAlignment = Alignment.Top
              ) {
                Text(
                  text = "${idx + 1}.",
                  color = CyberCyan,
                  fontWeight = FontWeight.Bold,
                  fontSize = 12.sp,
                  modifier = Modifier.width(20.dp)
                )
                Text(
                  text = step,
                  color = TextSecondary,
                  fontSize = 12.sp,
                  lineHeight = 17.sp
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = DarkSurfaceElevated,
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = "Notice: ${game.technicalNotes}",
                fontSize = 11.sp,
                color = TextMuted,
                modifier = Modifier.padding(10.dp),
                lineHeight = 15.sp
              )
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}

@Composable
private fun SettingParamRow(label: String, value: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 3.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(text = label, fontSize = 12.sp, color = TextSecondary)
    Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
  }
}
