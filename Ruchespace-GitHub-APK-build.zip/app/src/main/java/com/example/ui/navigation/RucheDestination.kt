package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SettingsInputComponent
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideogameAsset
import androidx.compose.ui.graphics.vector.ImageVector

enum class RucheDestination(
  val route: String,
  val label: String,
  val icon: ImageVector,
  val title: String
) {
  DASHBOARD("dashboard", "HUD", Icons.Default.Dashboard, "RucheSpace Game HUD"),
  GRAPHICS("graphics", "Graphics", Icons.Default.Tune, "Graphics & Resolution Optimizer"),
  REFRESH_RATE("refresh", "Refresh & FPS", Icons.Default.Speed, "Refresh Rate & Frame Pacing"),
  CPU_GPU("cpu_gpu", "Hardware", Icons.Default.Memory, "CPU / GPU Performance Center"),
  PROFILES("profiles", "Profiles", Icons.Default.VideogameAsset, "Gaming Profiles"),
  SHIZUKU("shizuku", "Shizuku", Icons.Default.SettingsInputComponent, "Shizuku Engine Bridge"),
  TEST_CENTER("test_center", "Diagnostics", Icons.Default.BarChart, "Performance Test Center"),
  SAFETY("safety", "Safety", Icons.Default.Security, "Safety & Capability Matrix")
}
