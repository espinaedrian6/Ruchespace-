package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideogameAsset
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.CapabilitySupportLevel
import com.example.ui.RucheSpaceViewModel
import com.example.ui.components.CyberCard
import com.example.ui.components.LiveFrameGraph
import com.example.ui.components.SafetyBadge
import com.example.ui.navigation.RucheDestination
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkBorderGlow
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun DashboardScreen(
  viewModel: RucheSpaceViewModel,
  onNavigate: (RucheDestination) -> Unit,
  modifier: Modifier = Modifier
) {
  val displayInfo by viewModel.displayInfo.collectAsStateWithLifecycle()
  val batteryTelemetry by viewModel.batteryTelemetry.collectAsStateWithLifecycle()
  val thermalInfo by viewModel.thermalInfo.collectAsStateWithLifecycle()
  val memoryTelemetry by viewModel.memoryTelemetry.collectAsStateWithLifecycle()
  val bottleneck by viewModel.bottleneck.collectAsStateWithLifecycle()
  val activeProfileId by viewModel.activeProfileId.collectAsStateWithLifecycle()
  val fpsMetrics by viewModel.fpsMetrics.collectAsStateWithLifecycle()
  val selectedFpsTarget by viewModel.selectedFpsTarget.collectAsStateWithLifecycle()
  val shizukuState by viewModel.shizukuController.shizukuState.collectAsStateWithLifecycle()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(4.dp))
      // Top HUD Header
      CyberCard(
        borderColor = CyberCyan.copy(alpha = 0.5f),
        glowAccent = CyberCyan
      ) {
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "RUCHESPACE ENGINE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                color = CyberCyan
              )
              Text(
                text = "Game Performance HUD",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
            }

            com.example.ui.components.ShizukuStatusBadge(
              isGranted = shizukuState.isPermissionGranted,
              isBinderAlive = shizukuState.isBinderAlive,
              onClick = { onNavigate(RucheDestination.SHIZUKU) }
            )
          }

          Spacer(modifier = Modifier.height(16.dp))

          // 4 Key Metrics Bar
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            MetricTile(
              label = "PANEL RATE",
              value = "${displayInfo.currentRefreshRate.toInt()} Hz",
              sub = "${displayInfo.currentWidth}x${displayInfo.currentHeight}",
              color = CyberCyan
            )
            MetricTile(
              label = "MEASURED FPS",
              value = String.format("%.0f", fpsMetrics.rollingFps),
              sub = "1% Low: ${String.format("%.0f", fpsMetrics.onePercentLowFps)}",
              color = EmeraldGlow
            )
            MetricTile(
              label = "BATTERY TEMP",
              value = "${String.format("%.1f", batteryTelemetry.temperatureCelsius)}°C",
              sub = "${batteryTelemetry.levelPercent}% (${batteryTelemetry.chargingStatus})",
              color = if (batteryTelemetry.temperatureCelsius > 41f) AmberWarning else TextPrimary
            )
            MetricTile(
              label = "RAM HEADROOM",
              value = "${memoryTelemetry.availableRamMb} MB",
              sub = "${memoryTelemetry.usedRamPercent}% used",
              color = NeonViolet
            )
          }
        }
      }
    }

    // Live Frame Graph
    item {
      LiveFrameGraph(
        frameTimesMs = fpsMetrics.frameHistoryMs,
        currentFps = fpsMetrics.rollingFps,
        targetFps = selectedFpsTarget,
        modifier = Modifier.testTag("dashboard_live_frame_graph")
      )
    }

    // Active Profile Switcher & Quick Tuning
    item {
      CyberCard {
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.VideogameAsset, contentDescription = null, tint = NeonViolet)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "ACTIVE GAMING PROFILE",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = TextPrimary
              )
            }

            OutlinedButton(
              onClick = { onNavigate(RucheDestination.PROFILES) },
              modifier = Modifier.height(32.dp).testTag("view_all_profiles_button")
            ) {
              Text("Manage", fontSize = 11.sp, color = CyberCyan)
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = activeProfileId.displayName,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = CyberCyan
          )
          Text(
            text = "Target Framerate: ${selectedFpsTarget} FPS • Panel: ${displayInfo.currentRefreshRate.toInt()}Hz • Thermal Guard: Active",
            fontSize = 13.sp,
            color = TextSecondary
          )

          Spacer(modifier = Modifier.height(12.dp))

          // Quick FPS Target selector pills
          Text(
            text = "QUICK FPS TARGET LIMITER",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted,
            letterSpacing = 0.5.sp
          )
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            listOf(30, 45, 60, 90, 120).forEach { target ->
              val isSelected = selectedFpsTarget == target
              Surface(
                modifier = Modifier
                  .weight(1f)
                  .clip(RoundedCornerShape(8.dp))
                  .border(
                    1.dp,
                    if (isSelected) CyberCyan else DarkBorder,
                    RoundedCornerShape(8.dp)
                  )
                  .testTag("fps_pill_$target"),
                color = if (isSelected) CyberCyan.copy(alpha = 0.2f) else DarkSurfaceElevated,
                onClick = { viewModel.selectFpsTarget(target) }
              ) {
                Box(
                  modifier = Modifier.padding(vertical = 8.dp),
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    text = "$target",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) CyberCyan else TextSecondary,
                    fontFamily = FontFamily.Monospace
                  )
                }
              }
            }
          }
        }
      }
    }

    // Bottleneck Diagnostics
    item {
      CyberCard(borderColor = Color(bottleneck.primaryBottleneck.badgeColor).copy(alpha = 0.4f)) {
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Bolt, contentDescription = null, tint = Color(bottleneck.primaryBottleneck.badgeColor))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "BOTTLENECK DIAGNOSTIC",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = TextPrimary
              )
            }

            Surface(
              shape = RoundedCornerShape(6.dp),
              color = Color(bottleneck.primaryBottleneck.badgeColor).copy(alpha = 0.15f)
            ) {
              Text(
                text = bottleneck.primaryBottleneck.title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(bottleneck.primaryBottleneck.badgeColor),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = bottleneck.actionableRemedy,
            fontSize = 13.sp,
            color = TextPrimary,
            lineHeight = 18.sp
          )

          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = bottleneck.safeOptimizationNotice,
            fontSize = 11.sp,
            color = TextMuted
          )
        }
      }
    }

    // Quick Navigation Grid
    item {
      Text(
        text = "ADVANCED CONTROL MODULES",
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        color = TextMuted,
        modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
      )

      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ModuleLinkRow(
          title = "12 & 15. Graphics & Pixel Scaling",
          sub = "Display modes, resolution presets & game guides",
          icon = Icons.Default.Tune,
          badge = "Safe Revert",
          onClick = { onNavigate(RucheDestination.GRAPHICS) }
        )
        ModuleLinkRow(
          title = "13 & 14. Refresh Rate & FPS Engine",
          sub = "60/90/120/144Hz controller & jitter analyzer",
          icon = Icons.Default.Speed,
          badge = "Choreographer",
          onClick = { onNavigate(RucheDestination.REFRESH_RATE) }
        )
        ModuleLinkRow(
          title = "16. CPU & GPU Performance Center",
          sub = "SoC cores, Vulkan capabilities & thermal headroom",
          icon = Icons.Default.Memory,
          badge = "Telemetry",
          onClick = { onNavigate(RucheDestination.CPU_GPU) }
        )
        ModuleLinkRow(
          title = "18. Shizuku Advanced Engine",
          sub = "ADB binder bridge, strict allowlist & vendor guides",
          icon = Icons.Default.Security,
          badge = if (shizukuState.isPermissionGranted) "Connected" else "Bridge",
          onClick = { onNavigate(RucheDestination.SHIZUKU) }
        )
        ModuleLinkRow(
          title = "19. Performance Test Center",
          sub = "Live stress testing & saved diagnostic reports",
          icon = Icons.Default.Speed,
          badge = "Room DB",
          onClick = { onNavigate(RucheDestination.TEST_CENTER) }
        )
        ModuleLinkRow(
          title = "20. Safety & Compatibility Matrix",
          sub = "Runtime capability matrix & hardware boundaries",
          icon = Icons.Default.Check,
          badge = "100% Safe",
          onClick = { onNavigate(RucheDestination.SAFETY) }
        )
      }
    }

    item {
      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}

@Composable
private fun MetricTile(
  label: String,
  value: String,
  sub: String,
  color: Color
) {
  Column {
    Text(
      text = label,
      fontSize = 10.sp,
      fontWeight = FontWeight.Bold,
      color = TextMuted,
      letterSpacing = 0.5.sp
    )
    Spacer(modifier = Modifier.height(2.dp))
    Text(
      text = value,
      fontSize = 17.sp,
      fontWeight = FontWeight.Bold,
      color = color,
      fontFamily = FontFamily.Monospace
    )
    Spacer(modifier = Modifier.height(2.dp))
    Text(
      text = sub,
      fontSize = 10.sp,
      color = TextSecondary
    )
  }
}

@Composable
private fun ModuleLinkRow(
  title: String,
  sub: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  badge: String,
  onClick: () -> Unit
) {
  CyberCard(
    modifier = Modifier.fillMaxWidth(),
    onClick = onClick
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(DarkSurfaceElevated)
            .border(1.dp, DarkBorder, RoundedCornerShape(10.dp)),
          contentAlignment = Alignment.Center
        ) {
          Icon(icon, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
          Text(text = sub, fontSize = 12.sp, color = TextSecondary)
        }
      }

      Surface(
        shape = RoundedCornerShape(6.dp),
        color = CyberCyan.copy(alpha = 0.12f),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.3f))
      ) {
        Text(
          text = badge,
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold,
          color = CyberCyan,
          modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
        )
      }
    }
  }
}
