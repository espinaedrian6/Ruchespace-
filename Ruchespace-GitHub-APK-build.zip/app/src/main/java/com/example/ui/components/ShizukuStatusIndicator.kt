package com.example.ui.components

import android.content.pm.PackageManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ShizukuState
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkBorderGlow
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import rikka.shizuku.Shizuku

/**
 * High-fidelity UI indicator that displays the current Shizuku permission status
 * and offers direct actions (request permission, refresh connection, or run IPC test).
 */
@Composable
fun ShizukuPermissionStatusIndicator(
  shizukuState: ShizukuState,
  onRequestPermission: () -> Unit,
  onRefresh: () -> Unit,
  modifier: Modifier = Modifier,
  onTestIpcEcho: (() -> Unit)? = null
) {
  val isConnectedAndGranted = shizukuState.isBinderAlive && shizukuState.isPermissionGranted
  val isServiceRunningNoPermission = shizukuState.isBinderAlive && !shizukuState.isPermissionGranted
  val isOffline = !shizukuState.isBinderAlive

  val accentColor by animateColorAsState(
    targetValue = when {
      isConnectedAndGranted -> EmeraldGlow
      isServiceRunningNoPermission -> AmberWarning
      else -> CrimsonAlert
    },
    label = "shizuku_accent_color"
  )

  val infiniteTransition = rememberInfiniteTransition(label = "pulse_transition")
  val pulseScale by infiniteTransition.animateFloat(
    initialValue = 0.95f,
    targetValue = 1.15f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 1200),
      repeatMode = RepeatMode.Reverse
    ),
    label = "dot_pulse"
  )

  CyberCard(
    modifier = modifier.testTag("shizuku_status_card"),
    borderColor = accentColor.copy(alpha = 0.5f),
    glowAccent = if (isConnectedAndGranted) EmeraldGlow else null
  ) {
    Column {
      // Header row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(12.dp)
              .scale(if (isConnectedAndGranted || isServiceRunningNoPermission) pulseScale else 1f)
              .clip(CircleShape)
              .background(accentColor)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "SHIZUKU PERMISSION & BINDER",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 1.sp,
              color = accentColor
            )
            Text(
              text = when {
                isConnectedAndGranted -> "Authorized (ADB Sandboxed)"
                isServiceRunningNoPermission -> "Permission Required"
                else -> "Service Offline"
              },
              fontSize = 17.sp,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          }
        }

        // Status Badge Pill
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = accentColor.copy(alpha = 0.15f),
          border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.4f))
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = when {
                isConnectedAndGranted -> Icons.Default.CheckCircle
                isServiceRunningNoPermission -> Icons.Default.Warning
                else -> Icons.Default.Info
              },
              contentDescription = null,
              tint = accentColor,
              modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
              text = when {
                isConnectedAndGranted -> "ACTIVE"
                isServiceRunningNoPermission -> "DENIED"
                else -> "DISCONNECTED"
              },
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 0.5.sp,
              color = accentColor
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Status text description
      Text(
        text = when {
          isConnectedAndGranted ->
            "Shizuku v${shizukuState.shizukuVersion} connected (Server UID ${shizukuState.serverUid}). Elevated ADB settings commands (system refresh rate & density scaling) are unlocked."
          isServiceRunningNoPermission ->
            "The Shizuku binder service is running on your device, but RucheSpace does not have permission yet. Grant permission to unlock system-wide refresh rate and density tuning without root."
          else ->
            "Shizuku binder is currently not responding. Launch the Shizuku app and start the service via Wireless Debugging (Android 11+) or a connected computer via ADB."
        },
        fontSize = 12.sp,
        color = TextSecondary,
        lineHeight = 17.sp
      )

      Spacer(modifier = Modifier.height(14.dp))

      // Action buttons
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        when {
          isServiceRunningNoPermission -> {
            Button(
              onClick = onRequestPermission,
              colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
              modifier = Modifier
                .weight(1f)
                .height(38.dp)
                .testTag("grant_shizuku_permission_button")
            ) {
              Icon(Icons.Default.Security, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Grant Shizuku Permission", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }

            OutlinedButton(
              onClick = onRefresh,
              modifier = Modifier
                .height(38.dp)
                .testTag("refresh_shizuku_status_button")
            ) {
              Icon(Icons.Default.Refresh, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Re-check", fontSize = 11.sp, color = TextSecondary)
            }
          }

          isConnectedAndGranted -> {
            if (onTestIpcEcho != null) {
              Button(
                onClick = onTestIpcEcho,
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldGlow),
                modifier = Modifier
                  .weight(1f)
                  .height(38.dp)
                  .testTag("test_shizuku_echo_button")
              ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Test IPC Echo", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
              }
            }

            OutlinedButton(
              onClick = onRefresh,
              modifier = Modifier
                .height(38.dp)
                .testTag("refresh_shizuku_status_button")
            ) {
              Icon(Icons.Default.Refresh, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Refresh", fontSize = 11.sp, color = TextSecondary)
            }
          }

          else -> { // isOffline
            Button(
              onClick = onRefresh,
              colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
              modifier = Modifier
                .fillMaxWidth()
                .height(38.dp)
                .border(1.dp, DarkBorderGlow, RoundedCornerShape(20.dp))
                .testTag("refresh_shizuku_status_button")
            ) {
              Icon(Icons.Default.Refresh, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Check Service Connection", color = CyberCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
          }
        }
      }
    }
  }
}

/**
 * Self-contained Shizuku status indicator that checks the Shizuku Binder and
 * permission directly at runtime, reacting to lifecycle and binder connection events.
 */
@Composable
fun ShizukuStatusIndicator(
  modifier: Modifier = Modifier,
  onRequestPermissionClick: (() -> Unit)? = null,
  onStatusChanged: ((Boolean) -> Unit)? = null
) {
  var isBinderAlive by remember { mutableStateOf(false) }
  var isPermissionGranted by remember { mutableStateOf(false) }
  var shizukuVersion by remember { mutableIntStateOf(0) }
  var serverUid by remember { mutableIntStateOf(-1) }

  fun queryShizuku() {
    try {
      val alive = Shizuku.pingBinder()
      isBinderAlive = alive
      if (alive) {
        val granted = Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        isPermissionGranted = granted
        shizukuVersion = try { Shizuku.getVersion() } catch (_: Throwable) { 0 }
        serverUid = try { Shizuku.getUid() } catch (_: Throwable) { -1 }
        onStatusChanged?.invoke(granted)
      } else {
        isPermissionGranted = false
        onStatusChanged?.invoke(false)
      }
    } catch (_: Throwable) {
      isBinderAlive = false
      isPermissionGranted = false
      onStatusChanged?.invoke(false)
    }
  }

  DisposableEffect(Unit) {
    queryShizuku()

    val receivedListener = Shizuku.OnBinderReceivedListener {
      queryShizuku()
    }
    val deadListener = Shizuku.OnBinderDeadListener {
      queryShizuku()
    }
    val permListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
      queryShizuku()
    }

    try {
      Shizuku.addBinderReceivedListenerSticky(receivedListener)
      Shizuku.addBinderDeadListener(deadListener)
      Shizuku.addRequestPermissionResultListener(permListener)
    } catch (_: Throwable) {}

    onDispose {
      try {
        Shizuku.removeBinderReceivedListener(receivedListener)
        Shizuku.removeBinderDeadListener(deadListener)
        Shizuku.removeRequestPermissionResultListener(permListener)
      } catch (_: Throwable) {}
    }
  }

  val state = remember(isBinderAlive, isPermissionGranted, shizukuVersion, serverUid) {
    ShizukuState(
      isServiceAvailable = isBinderAlive,
      isBinderAlive = isBinderAlive,
      isPermissionGranted = isPermissionGranted,
      shizukuVersion = shizukuVersion,
      serverUid = serverUid,
      connectionStatusText = if (isPermissionGranted) "Authorized" else "Not Authorized"
    )
  }

  ShizukuPermissionStatusIndicator(
    shizukuState = state,
    onRequestPermission = {
      if (onRequestPermissionClick != null) {
        onRequestPermissionClick()
      } else {
        try {
          if (Shizuku.pingBinder()) {
            Shizuku.requestPermission(7001)
          }
        } catch (_: Throwable) {}
      }
    },
    onRefresh = { queryShizuku() },
    modifier = modifier
  )
}

/**
 * Compact Pill Badge for displaying Shizuku status in toolbars or cards.
 */
@Composable
fun ShizukuStatusBadge(
  isGranted: Boolean,
  isBinderAlive: Boolean,
  modifier: Modifier = Modifier,
  onClick: (() -> Unit)? = null
) {
  val color = when {
    isBinderAlive && isGranted -> EmeraldGlow
    isBinderAlive -> AmberWarning
    else -> TextMuted
  }

  val text = when {
    isBinderAlive && isGranted -> "SHIZUKU READY"
    isBinderAlive -> "SHIZUKU PERM NEEDED"
    else -> "SHIZUKU OFFLINE"
  }

  val baseModifier = modifier
    .clip(RoundedCornerShape(12.dp))
    .background(color.copy(alpha = 0.12f))
    .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(12.dp))

  val clickableModifier = if (onClick != null) {
    baseModifier.clickable(onClick = onClick)
  } else {
    baseModifier
  }

  Row(
    modifier = clickableModifier.padding(horizontal = 8.dp, vertical = 4.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Box(
      modifier = Modifier
        .size(6.dp)
        .clip(CircleShape)
        .background(color)
    )
    Spacer(modifier = Modifier.width(6.dp))
    Text(
      text = text,
      color = color,
      fontSize = 10.sp,
      fontWeight = FontWeight.Bold,
      letterSpacing = 0.5.sp
    )
  }
}
