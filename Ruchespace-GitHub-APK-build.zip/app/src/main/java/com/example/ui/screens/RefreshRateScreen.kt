package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.RucheSpaceViewModel
import com.example.ui.components.CyberCard
import com.example.ui.components.LiveFrameGraph
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkBorderGlow
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
fun RefreshRateScreen(
  viewModel: RucheSpaceViewModel,
  modifier: Modifier = Modifier
) {
  val displayInfo by viewModel.displayInfo.collectAsStateWithLifecycle()
  val fpsMetrics by viewModel.fpsMetrics.collectAsStateWithLifecycle()
  val selectedFpsTarget by viewModel.selectedFpsTarget.collectAsStateWithLifecycle()
  val shizukuState by viewModel.shizukuController.shizukuState.collectAsStateWithLifecycle()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Current Active Refresh Rate & Mode
    item {
      Spacer(modifier = Modifier.height(4.dp))
      CyberCard(glowAccent = CyberCyan) {
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "ACTIVE DISPLAY REFRESH RATE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = CyberCyan
              )
              Row(verticalAlignment = Alignment.Bottom) {
                Text(
                  text = "${displayInfo.currentRefreshRate.toInt()}",
                  fontSize = 34.sp,
                  fontWeight = FontWeight.Bold,
                  fontFamily = FontFamily.Monospace,
                  color = TextPrimary
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "Hz",
                  fontSize = 18.sp,
                  fontWeight = FontWeight.Bold,
                  color = CyberCyan,
                  modifier = Modifier.padding(bottom = 4.dp)
                )
              }
            }

            OutlinedButton(
              onClick = { viewModel.resetRefreshRateDefaults() },
              modifier = Modifier.testTag("restore_refresh_defaults_button")
            ) {
              Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp), tint = TextSecondary)
              Spacer(modifier = Modifier.width(6.dp))
              Text("Restore Default", fontSize = 11.sp, color = TextSecondary)
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = "Active Resolution Mode: ${displayInfo.currentWidth} x ${displayInfo.currentHeight} @ ${String.format("%.1f", displayInfo.currentRefreshRate)}Hz",
            fontSize = 12.sp,
            color = TextSecondary,
            fontFamily = FontFamily.Monospace
          )
        }
      }
    }

    // Supported Refresh Rate Selector (Feature 13)
    item {
      Text(
        text = "HARDWARE SUPPORTED REFRESH RATES",
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        color = TextMuted,
        modifier = Modifier.padding(start = 4.dp)
      )
      Spacer(modifier = Modifier.height(4.dp))

      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        displayInfo.supportedRefreshRates.forEach { rate ->
          val isCurrent = (displayInfo.currentRefreshRate.roundToInt()) == rate.roundToInt()

          CyberCard(
            borderColor = if (isCurrent) CyberCyan else DarkBorder,
            glowAccent = if (isCurrent) CyberCyan else null
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(if (isCurrent) EmeraldGlow else DarkBorder)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                  Text(
                    text = "${rate.toInt()} Hz Mode",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                  )
                  Text(
                    text = if (isCurrent) "Current Hardware Output Rate" else "Hardware Verified Compatible",
                    fontSize = 11.sp,
                    color = if (isCurrent) EmeraldGlow else TextSecondary
                  )
                }
              }

              if (!isCurrent) {
                Button(
                  onClick = { viewModel.setPreferredRefreshRate(rate) },
                  colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                  modifier = Modifier.height(34.dp).testTag("select_refresh_rate_${rate.toInt()}")
                ) {
                  Text("Set ${rate.toInt()}Hz", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                }
              } else {
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = EmeraldGlow.copy(alpha = 0.15f)
                ) {
                  Text(
                    text = "ACTIVE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldGlow,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                  )
                }
              }
            }
          }
        }
      }
    }

    // Clarification Notice: Refresh Rate vs Engine Limit vs Measured FPS (Feature 14)
    item {
      CyberCard(borderColor = NeonViolet.copy(alpha = 0.4f)) {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Info, contentDescription = null, tint = NeonViolet)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "CRUCIAL DISTINCTION: REFRESH vs LIMIT vs FPS",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          MetricDistinctionRow(
            label = "1. Display Refresh Rate",
            desc = "Physical hardware rate the panel redraws (e.g. 120Hz = 120 times/sec). RucheSpace can configure this on supported displays."
          )
          MetricDistinctionRow(
            label = "2. Game Frame-Rate Limit",
            desc = "Internal cap coded inside the game engine (e.g. 30, 60, 90 FPS). Changing Android system display settings CANNOT force an internal 60 FPS locked game to render at 120 FPS without game updates."
          )
          MetricDistinctionRow(
            label = "3. Measured FPS",
            desc = "The actual real-time frames delivered by the GPU and SurfaceFlinger. True hardware telemetry."
          )
        }
      }
    }

    // Live Frame-Time Telemetry Graph & Jitter Analyzer
    item {
      LiveFrameGraph(
        frameTimesMs = fpsMetrics.frameHistoryMs,
        currentFps = fpsMetrics.rollingFps,
        targetFps = selectedFpsTarget,
        modifier = Modifier.testTag("refresh_live_graph")
      )
    }

    // Real-Time Frame-Time Stability Statistics
    item {
      CyberCard {
        Column {
          Text(
            text = "CHOREOGRAPHER STABILITY DIAGNOSTICS",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted,
            letterSpacing = 0.5.sp
          )
          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            DiagnosticBox(
              label = "AVG FRAME TIME",
              value = "${String.format("%.2f", fpsMetrics.avgFrameTimeMs)} ms",
              sub = "16.6ms ideal for 60Hz"
            )
            DiagnosticBox(
              label = "1% LOW FPS",
              value = String.format("%.1f", fpsMetrics.onePercentLowFps),
              sub = "Worst 1% frame drops"
            )
            DiagnosticBox(
              label = "JITTER (STDEV)",
              value = "±${String.format("%.2f", fpsMetrics.frameTimeJitterMs)} ms",
              sub = if (fpsMetrics.frameTimeJitterMs < 2.0f) "Smooth" else "Frame pacing variance"
            )
            DiagnosticBox(
              label = "JANKS DETECTED",
              value = "${fpsMetrics.jankFramesCount}",
              sub = "Frames > 20ms"
            )
          }
        }
      }
    }

    // Selectable FPS Targets (Feature 14)
    item {
      Text(
        text = "SELECTABLE FPS PACING TARGETS",
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        color = TextMuted,
        modifier = Modifier.padding(start = 4.dp)
      )
      Spacer(modifier = Modifier.height(4.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        listOf(30, 45, 60, 90, 120, 144).forEach { target ->
          val isSelected = selectedFpsTarget == target
          Surface(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .border(
                1.dp,
                if (isSelected) CyberCyan else DarkBorder,
                RoundedCornerShape(10.dp)
              )
              .testTag("fps_target_btn_$target"),
            color = if (isSelected) CyberCyan.copy(alpha = 0.2f) else DarkSurfaceElevated,
            onClick = { viewModel.selectFpsTarget(target) }
          ) {
            Column(
              modifier = Modifier.padding(vertical = 10.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text(
                text = "$target",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) CyberCyan else TextPrimary,
                fontFamily = FontFamily.Monospace
              )
              Text(
                text = "FPS",
                fontSize = 9.sp,
                color = TextSecondary
              )
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}

@Composable
private fun MetricDistinctionRow(label: String, desc: String) {
  Column(modifier = Modifier.padding(vertical = 4.dp)) {
    Text(text = label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CyberCyan)
    Text(text = desc, fontSize = 11.sp, color = TextSecondary, lineHeight = 16.sp)
  }
}

@Composable
private fun DiagnosticBox(label: String, value: String, sub: String) {
  Column {
    Text(text = label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextMuted)
    Spacer(modifier = Modifier.height(2.dp))
    Text(text = value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary, fontFamily = FontFamily.Monospace)
    Spacer(modifier = Modifier.height(2.dp))
    Text(text = sub, fontSize = 9.sp, color = TextSecondary)
  }
}
