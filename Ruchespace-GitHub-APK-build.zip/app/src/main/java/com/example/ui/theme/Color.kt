package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberCyan = Color(0xFF00E5FF)
val CyberCyanDark = Color(0xFF00B4D8)
val NeonViolet = Color(0xFFA855F7)
val EmeraldGlow = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val CrimsonAlert = Color(0xFFFF4D4D)

val DarkVoid = Color(0xFF070A10)
val DarkSurface = Color(0xFF0D131F)
val DarkSurfaceElevated = Color(0xFF141C2B)
val DarkSurfaceCard = Color(0xFF192233)
val DarkBorder = Color(0xFF243247)
val DarkBorderGlow = Color(0xFF2C3E5B)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val AccentGold = Color(0xFFFFD166)
