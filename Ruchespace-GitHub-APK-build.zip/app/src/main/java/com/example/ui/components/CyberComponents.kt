package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CapabilitySupportLevel
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkBorderGlow
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun CyberCard(
  modifier: Modifier = Modifier,
  borderColor: Color = DarkBorder,
  glowAccent: Color? = null,
  onClick: (() -> Unit)? = null,
  content: @Composable () -> Unit
) {
  val shape = RoundedCornerShape(16.dp)
  val baseModifier = modifier
    .clip(shape)
    .background(
      brush = Brush.verticalGradient(
        colors = listOf(
          DarkSurfaceCard,
          DarkSurfaceElevated
        )
      )
    )
    .border(
      width = 1.dp,
      brush = Brush.horizontalGradient(
        colors = listOf(
          glowAccent ?: borderColor,
          DarkBorder
        )
      ),
      shape = shape
    )

  val finalModifier = if (onClick != null) {
    baseModifier.clickable(onClick = onClick)
  } else {
    baseModifier
  }

  Box(modifier = finalModifier.padding(16.dp)) {
    content()
  }
}

@Composable
fun SafetyBadge(
  level: CapabilitySupportLevel,
  modifier: Modifier = Modifier
) {
  val color = Color(level.badgeColor)
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(8.dp),
    color = color.copy(alpha = 0.15f),
    border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.4f))
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(6.dp)
          .clip(CircleShape)
          .background(color)
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = level.badgeLabel,
        color = color,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.5.sp
      )
    }
  }
}

@Composable
fun LiveFrameGraph(
  frameTimesMs: List<Float>,
  currentFps: Float,
  targetFps: Int,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .background(DarkSurfaceElevated)
      .border(1.dp, DarkBorderGlow, RoundedCornerShape(14.dp))
      .padding(12.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(8.dp)
            .clip(CircleShape)
            .background(EmeraldGlow)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "LIVE FRAME-TIME TELEMETRY",
          color = TextPrimary,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 1.sp
        )
      }

      Text(
        text = "${String.format("%.1f", currentFps)} FPS",
        color = CyberCyan,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    Canvas(
      modifier = Modifier
        .fillMaxWidth()
        .height(110.dp)
    ) {
      val w = size.width
      val h = size.height

      // Grid guidelines
      // 16.6ms line (60 FPS limit)
      // 8.33ms line (120 FPS limit)
      val maxDisplayMs = 33.3f // 30 FPS boundary
      fun yForMs(ms: Float): Float {
        return h - ((ms / maxDisplayMs).coerceIn(0f, 1f) * h)
      }

      val y16 = yForMs(16.66f)
      val y8 = yForMs(8.33f)

      // 60Hz marker
      drawLine(
        color = DarkBorder,
        start = Offset(0f, y16),
        end = Offset(w, y16),
        strokeWidth = 1.dp.toPx(),
        pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
      )

      // 120Hz marker
      drawLine(
        color = DarkBorder,
        start = Offset(0f, y8),
        end = Offset(w, y8),
        strokeWidth = 1.dp.toPx(),
        pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
      )

      if (frameTimesMs.size >= 2) {
        val stepX = w / (frameTimesMs.size - 1).coerceAtLeast(1)
        val path = Path()
        val fillPath = Path()

        frameTimesMs.forEachIndexed { index, timeMs ->
          val x = index * stepX
          val y = yForMs(timeMs)
          if (index == 0) {
            path.moveTo(x, y)
            fillPath.moveTo(x, h)
            fillPath.lineTo(x, y)
          } else {
            path.lineTo(x, y)
            fillPath.lineTo(x, y)
          }
        }
        fillPath.lineTo(w, h)
        fillPath.close()

        drawPath(
          path = fillPath,
          brush = Brush.verticalGradient(
            colors = listOf(CyberCyan.copy(alpha = 0.25f), Color.Transparent)
          )
        )

        drawPath(
          path = path,
          color = CyberCyan,
          style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
        )
      }
    }

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(top = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text("Target: ${targetFps} FPS", color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
      Text("Guide: 16.6ms (60Hz) / 8.3ms (120Hz)", color = TextMuted, fontSize = 11.sp)
    }
  }
}

@Composable
fun AutoRevertDialog(
  title: String,
  message: String,
  remainingSeconds: Int,
  onConfirmKeep: () -> Unit,
  onRevertNow: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onRevertNow,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Warning, contentDescription = null, tint = AmberWarning)
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = title, color = TextPrimary)
      }
    },
    text = {
      Column {
        Text(text = message, color = TextSecondary, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(14.dp))
        Text(
          text = "Auto-reverting in $remainingSeconds seconds if unconfirmed...",
          color = AmberWarning,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace,
          fontSize = 13.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        LinearProgressIndicator(
          progress = { (remainingSeconds / 10f).coerceIn(0f, 1f) },
          modifier = Modifier.fillMaxWidth(),
          color = AmberWarning,
          trackColor = DarkSurfaceElevated
        )
      }
    },
    confirmButton = {
      Button(
        onClick = onConfirmKeep,
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldGlow),
        modifier = Modifier.testTag("confirm_keep_button")
      ) {
        Text("Keep Changes", color = Color.Black, fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      OutlinedButton(
        onClick = onRevertNow,
        modifier = Modifier.testTag("revert_now_button")
      ) {
        Text("Revert Immediately", color = CrimsonAlert)
      }
    },
    containerColor = DarkSurfaceCard,
    shape = RoundedCornerShape(16.dp)
  )
}
