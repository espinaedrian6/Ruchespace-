package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatterySaver
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.SettingsSuggest
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.GamingProfileConfig
import com.example.data.model.ProfileId
import com.example.ui.RucheSpaceViewModel
import com.example.ui.components.CyberCard
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkBorderGlow
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun GamingProfilesScreen(
  viewModel: RucheSpaceViewModel,
  modifier: Modifier = Modifier
) {
  val activeProfileId by viewModel.activeProfileId.collectAsStateWithLifecycle()
  val lastReport by viewModel.lastProfileReport.collectAsStateWithLifecycle()
  val displayInfo by viewModel.displayInfo.collectAsStateWithLifecycle()

  var profileToPreview by remember { mutableStateOf<GamingProfileConfig?>(null) }

  // Preview & Confirmation Dialog
  profileToPreview?.let { profile ->
    AlertDialog(
      onDismissRequest = { profileToPreview = null },
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(getProfileIcon(profile.iconKey), contentDescription = null, tint = CyberCyan)
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "Preview: ${profile.name}", color = TextPrimary, fontSize = 16.sp)
        }
      },
      text = {
        Column {
          Text(text = profile.subtitle, color = TextSecondary, fontSize = 13.sp)
          Spacer(modifier = Modifier.height(12.dp))

          ProfileMetricRow("Target Refresh Rate", "${profile.preferredRefreshRate?.toInt() ?: "Adaptive"} Hz")
          ProfileMetricRow("FPS Target Cap", "${profile.fpsTargetCap} FPS")
          ProfileMetricRow("Touch Polling Priority", if (profile.touchResponsePriority) "High Response" else "Standard")
          ProfileMetricRow("Thermal Policy", profile.thermalThrottlingAwareness)
          ProfileMetricRow("Resolution Scale", "${profile.resolutionScalePercent}% Native")

          Spacer(modifier = Modifier.height(10.dp))
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = DarkSurfaceElevated,
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = "RucheSpace automatically backs up original refresh rate (${displayInfo.currentRefreshRate.toInt()}Hz) and density before applying. 1-Tap Undo is always available.",
              fontSize = 11.sp,
              color = EmeraldGlow,
              modifier = Modifier.padding(8.dp)
            )
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.applyProfile(profile)
            profileToPreview = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
          modifier = Modifier.testTag("confirm_apply_profile_button")
        ) {
          Text("Confirm & Apply", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        OutlinedButton(onClick = { profileToPreview = null }) {
          Text("Cancel", color = TextSecondary)
        }
      },
      containerColor = DarkSurfaceCard,
      shape = RoundedCornerShape(16.dp)
    )
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Top Active Profile Summary & Undo Button
    item {
      Spacer(modifier = Modifier.height(4.dp))
      CyberCard(glowAccent = CyberCyan) {
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "CURRENT ACTIVE PROFILE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = CyberCyan
              )
              Text(
                text = activeProfileId.displayName,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
            }

            OutlinedButton(
              onClick = { viewModel.undoActiveProfile() },
              modifier = Modifier.testTag("undo_profile_button")
            ) {
              Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp), tint = TextSecondary)
              Spacer(modifier = Modifier.width(4.dp))
              Text("Undo / Reset", fontSize = 11.sp, color = TextSecondary)
            }
          }

          lastReport?.let { report ->
            Spacer(modifier = Modifier.height(12.dp))
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = DarkSurfaceElevated,
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text(
                  text = "LATEST APPLICATION REPORT:",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = EmeraldGlow
                )
                Spacer(modifier = Modifier.height(4.dp))
                report.changesApplied.forEach { change ->
                  Text(text = "• $change", fontSize = 11.sp, color = TextSecondary)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = report.backupSummary, fontSize = 10.sp, color = TextMuted)
              }
            }
          }
        }
      }
    }

    // Profiles List (Feature 17: 6 Profiles)
    item {
      Text(
        text = "VALIDATED GAMING PROFILES (6 PRESETS)",
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        color = TextMuted,
        modifier = Modifier.padding(start = 4.dp)
      )
    }

    items(viewModel.gamingProfiles) { profile ->
      val isActive = activeProfileId == profile.id

      CyberCard(
        borderColor = if (isActive) CyberCyan else DarkBorder,
        glowAccent = if (isActive) CyberCyan else null
      ) {
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              modifier = Modifier.weight(1f),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(40.dp)
                  .clip(RoundedCornerShape(10.dp))
                  .background(if (isActive) CyberCyan.copy(alpha = 0.2f) else DarkSurfaceElevated)
                  .border(1.dp, if (isActive) CyberCyan else DarkBorder, RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  getProfileIcon(profile.iconKey),
                  contentDescription = null,
                  tint = if (isActive) CyberCyan else TextSecondary,
                  modifier = Modifier.size(22.dp)
                )
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = profile.name,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                  )
                  if (isActive) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                      shape = RoundedCornerShape(4.dp),
                      color = EmeraldGlow.copy(alpha = 0.2f)
                    ) {
                      Text(
                        text = "ACTIVE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldGlow,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                      )
                    }
                  }
                }
                Text(
                  text = "FPS Cap: ${profile.fpsTargetCap} • Refresh: ${profile.preferredRefreshRate?.toInt() ?: "Adaptive"}Hz • Scale: ${profile.resolutionScalePercent}%",
                  fontSize = 11.sp,
                  color = CyberCyan
                )
              }
            }

            if (!isActive) {
              Button(
                onClick = { profileToPreview = profile },
                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                modifier = Modifier.height(34.dp).testTag("preview_profile_${profile.id.name}")
              ) {
                Text("Preview", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          Text(text = profile.subtitle, fontSize = 12.sp, color = TextSecondary)

          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Background Strategy: ${profile.backgroundProcessPolicy}",
            fontSize = 11.sp,
            color = TextMuted
          )
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}

private fun getProfileIcon(key: String): ImageVector {
  return when (key) {
    "speed" -> Icons.Default.Speed
    "sports_esports" -> Icons.Default.SportsEsports
    "tune" -> Icons.Default.Tune
    "battery_saver" -> Icons.Default.BatterySaver
    "show_chart" -> Icons.Default.ShowChart
    else -> Icons.Default.SettingsSuggest
  }
}

@Composable
private fun ProfileMetricRow(label: String, value: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 2.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(text = label, fontSize = 12.sp, color = TextSecondary)
    Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
  }
}
