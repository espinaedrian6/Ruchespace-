package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CapabilitySupportLevel
import com.example.ui.RucheSpaceViewModel
import com.example.ui.components.CyberCard
import com.example.ui.components.SafetyBadge
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SafetyMatrixScreen(
  viewModel: RucheSpaceViewModel,
  modifier: Modifier = Modifier
) {
  var selectedCategoryFilter by remember { mutableStateOf("All") }
  val allCapabilities = viewModel.safetyCapabilities
  val categories = listOf("All") + allCapabilities.map { it.category }.distinct()

  val filteredCapabilities = if (selectedCategoryFilter == "All") {
    allCapabilities
  } else {
    allCapabilities.filter { it.category == selectedCategoryFilter }
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Top Philosophy & Non-Root Assurance Card
    item {
      Spacer(modifier = Modifier.height(4.dp))
      CyberCard(glowAccent = EmeraldGlow) {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Security, contentDescription = null, tint = EmeraldGlow)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "SAFETY & COMPATIBILITY MATRIX",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 1.sp,
              color = EmeraldGlow
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = "Zero-Risk Engineering & Complete Transparency",
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "Every feature in RucheSpace is tested and categorized against Android platform specifications. We do not modify thermal protections, touch protected system files, or claim impossible universal game unlocks.",
            fontSize = 12.sp,
            color = TextSecondary,
            lineHeight = 17.sp
          )
        }
      }
    }

    // Category Filter Chips
    item {
      LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(categories) { category ->
          val isSelected = selectedCategoryFilter == category
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = if (isSelected) CyberCyan.copy(alpha = 0.2f) else DarkSurfaceElevated,
            border = androidx.compose.foundation.BorderStroke(
              1.dp,
              if (isSelected) CyberCyan else DarkBorder
            ),
            onClick = { selectedCategoryFilter = category },
            modifier = Modifier.testTag("filter_category_$category")
          ) {
            Text(
              text = category,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = if (isSelected) CyberCyan else TextSecondary,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
            )
          }
        }
      }
    }

    // Capabilities List
    items(filteredCapabilities) { cap ->
      CyberCard {
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = cap.title,
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              color = TextPrimary,
              modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            SafetyBadge(level = cap.supportLevel)
          }

          Spacer(modifier = Modifier.height(6.dp))
          Text(text = cap.explanation, fontSize = 12.sp, color = TextSecondary, lineHeight = 16.sp)

          Spacer(modifier = Modifier.height(8.dp))
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = DarkSurfaceElevated,
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(8.dp)) {
              Text(
                text = "TECHNICAL GUARDRAIL:",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = CyberCyan
              )
              Text(text = cap.technicalGuardrail, fontSize = 11.sp, color = TextMuted)
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}
