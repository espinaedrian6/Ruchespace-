package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.RucheSpaceViewModel
import com.example.ui.components.CyberCard
import com.example.ui.components.LiveFrameGraph
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PerformanceTestCenterScreen(
  viewModel: RucheSpaceViewModel,
  modifier: Modifier = Modifier
) {
  val benchmarkSession by viewModel.benchmarkSession.collectAsStateWithLifecycle()
  val savedReports by viewModel.savedReports.collectAsStateWithLifecycle()
  val fpsMetrics by viewModel.fpsMetrics.collectAsStateWithLifecycle()
  val selectedFpsTarget by viewModel.selectedFpsTarget.collectAsStateWithLifecycle()
  val displayInfo by viewModel.displayInfo.collectAsStateWithLifecycle()
  val batteryTelemetry by viewModel.batteryTelemetry.collectAsStateWithLifecycle()
  val memoryTelemetry by viewModel.memoryTelemetry.collectAsStateWithLifecycle()
  val thermalInfo by viewModel.thermalInfo.collectAsStateWithLifecycle()

  val isRunning = benchmarkSession?.isRunning == true

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Benchmark Recorder Header Card (Feature 19)
    item {
      Spacer(modifier = Modifier.height(4.dp))
      CyberCard(
        borderColor = if (isRunning) CrimsonAlert else CyberCyan,
        glowAccent = if (isRunning) CrimsonAlert else CyberCyan
      ) {
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "PERFORMANCE TEST RECORDER",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = if (isRunning) CrimsonAlert else CyberCyan
              )
              Text(
                text = if (isRunning) "Recording Live Telemetry..." else "Ready for Diagnostic Test",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
            }

            Surface(
              shape = RoundedCornerShape(20.dp),
              color = if (isRunning) CrimsonAlert.copy(alpha = 0.2f) else DarkSurfaceElevated
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (isRunning) CrimsonAlert else EmeraldGlow)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (isRunning) "${benchmarkSession?.elapsedSeconds}s Active" else "Idle",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (isRunning) CrimsonAlert else TextSecondary,
                  fontFamily = FontFamily.Monospace
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Real-time Session Metrics
          benchmarkSession?.let { session ->
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              SessionMetric("CURRENT FPS", String.format("%.1f", session.currentFps), CyberCyan)
              SessionMetric("AVG FPS", String.format("%.1f", session.averageFps), EmeraldGlow)
              SessionMetric("1% LOW", String.format("%.1f", session.onePercentLowFps), AmberWarning)
              SessionMetric("JITTER", "±${String.format("%.1f", session.jitterVarianceMs)}ms", NeonViolet)
            }
            Spacer(modifier = Modifier.height(10.dp))
          }

          // Start / Stop controls
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            if (!isRunning) {
              Button(
                onClick = { viewModel.startLiveBenchmark("Stress Test #${savedReports.size + 1}") },
                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                modifier = Modifier.weight(1f).testTag("start_benchmark_button")
              ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Start Benchmark Session", color = Color.Black, fontWeight = FontWeight.Bold)
              }
            } else {
              Button(
                onClick = { viewModel.stopAndSaveBenchmark() },
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert),
                modifier = Modifier.weight(1f).testTag("stop_save_benchmark_button")
              ) {
                Icon(Icons.Default.Stop, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Stop & Save Report", color = Color.White, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }

    // Live Frame Graph
    item {
      LiveFrameGraph(
        frameTimesMs = fpsMetrics.frameHistoryMs,
        currentFps = fpsMetrics.rollingFps,
        targetFps = selectedFpsTarget,
        modifier = Modifier.testTag("benchmark_live_graph")
      )
    }

    // Current Hardware Snapshot (Feature 19: Before/After Diagnostic Snapshot)
    item {
      CyberCard {
        Column {
          Text(
            text = "CURRENT HARDWARE DIAGNOSTIC SNAPSHOT",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted,
            letterSpacing = 0.5.sp
          )
          Spacer(modifier = Modifier.height(10.dp))

          SnapshotRow("Display Refresh Rate", "${displayInfo.currentRefreshRate.toInt()} Hz Native Mode")
          SnapshotRow("Measured Instant FPS", "${String.format("%.1f", fpsMetrics.rollingFps)} FPS")
          SnapshotRow("Frame-Time Jitter", "±${String.format("%.2f", fpsMetrics.frameTimeJitterMs)} ms")
          SnapshotRow("Available RAM", "${memoryTelemetry.availableRamMb} MB (${memoryTelemetry.totalRamMb} MB Total)")
          SnapshotRow("Available Storage", "${String.format("%.1f", memoryTelemetry.freeStorageGb)} GB (${String.format("%.1f", memoryTelemetry.totalStorageGb)} GB Total)")
          SnapshotRow("Battery Temperature", "${String.format("%.1f", batteryTelemetry.temperatureCelsius)} °C")
          SnapshotRow("Thermal Status", thermalInfo.statusLevel.title)
        }
      }
    }

    // Saved Diagnostic Reports in Local Room Database (Feature 19)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "SAVED BENCHMARK REPORTS (${savedReports.size})",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 1.sp,
          color = TextMuted
        )
      }
    }

    if (savedReports.isEmpty()) {
      item {
        CyberCard {
          Box(
            modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Icon(Icons.Default.Speed, contentDescription = null, tint = TextMuted, modifier = Modifier.size(36.dp))
              Spacer(modifier = Modifier.height(8.dp))
              Text("No Saved Reports Yet", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
              Text("Start a benchmark session to record hardware telemetry and save reports.", fontSize = 12.sp, color = TextSecondary)
            }
          }
        }
      }
    } else {
      items(savedReports) { report ->
        val dateFormat = SimpleDateFormat("MMM dd, yyyy HH:mm:ss", Locale.getDefault())
        val dateStr = dateFormat.format(Date(report.timestamp))

        CyberCard {
          Column {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(text = report.testName, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text(text = "$dateStr • ${report.durationSeconds}s Session", fontSize = 11.sp, color = TextMuted)
              }

              IconButton(
                onClick = { viewModel.deleteReport(report.id) },
                modifier = Modifier.size(28.dp).testTag("delete_report_${report.id}")
              ) {
                Icon(Icons.Default.Delete, contentDescription = "Delete Report", tint = CrimsonAlert.copy(alpha = 0.8f), modifier = Modifier.size(18.dp))
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              ReportStatPill("Avg FPS", String.format("%.1f", report.avgFps), CyberCyan)
              ReportStatPill("1% Low", String.format("%.1f", report.onePercentLowFps), EmeraldGlow)
              ReportStatPill("Avg Frame", "${String.format("%.1f", report.avgFrameTimeMs)}ms", TextPrimary)
              ReportStatPill("Jitter", "±${String.format("%.1f", report.jitterMs)}ms", NeonViolet)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
              text = "Battery: ${String.format("%.1f", report.batteryStartTemp)}°C → ${String.format("%.1f", report.batteryEndTemp)}°C • Peak Thermal: ${report.thermalStatusPeak} • Stutters: ${report.stuttersTotal}",
              fontSize = 11.sp,
              color = TextSecondary
            )
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}

@Composable
private fun SessionMetric(label: String, value: String, color: Color) {
  Column {
    Text(text = label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextMuted)
    Text(text = value, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = color, fontFamily = FontFamily.Monospace)
  }
}

@Composable
private fun SnapshotRow(label: String, value: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 3.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(text = label, fontSize = 12.sp, color = TextSecondary)
    Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
  }
}

@Composable
private fun ReportStatPill(label: String, value: String, color: Color) {
  Surface(
    shape = RoundedCornerShape(6.dp),
    color = DarkSurfaceElevated
  ) {
    Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
      Text(text = label, fontSize = 9.sp, color = TextMuted)
      Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color, fontFamily = FontFamily.Monospace)
    }
  }
}
