package com.example

import com.example.data.model.DEFAULT_GAMING_PROFILES
import com.example.data.model.PRESET_GAME_GRAPHICS
import com.example.data.model.ProfileId
import com.example.data.model.SYSTEM_SAFETY_CAPABILITIES
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun testGamingProfilesPresence() {
    val profiles = DEFAULT_GAMING_PROFILES
    assertEquals(6, profiles.size)
    val ids = profiles.map { it.id }
    assertTrue(ids.contains(ProfileId.MAX_PERFORMANCE))
    assertTrue(ids.contains(ProfileId.COMPETITIVE))
    assertTrue(ids.contains(ProfileId.BALANCED))
    assertTrue(ids.contains(ProfileId.BATTERY_SAVER))
    assertTrue(ids.contains(ProfileId.LOW_GRAPHICS_STABLE_FPS))
    assertTrue(ids.contains(ProfileId.CUSTOM))
  }

  @Test
  fun testGameGraphicsDatabase() {
    val games = PRESET_GAME_GRAPHICS
    assertTrue(games.size >= 5)
    val genshin = games.firstOrNull { it.id == "genshin_impact" }
    assertNotNull(genshin)
    assertTrue(genshin!!.inGameInstructions.isNotEmpty())
    assertTrue(genshin.nativeFpsCap.contains("60"))
  }

  @Test
  fun testSafetyCapabilitiesMatrix() {
    val matrix = SYSTEM_SAFETY_CAPABILITIES
    assertTrue(matrix.isNotEmpty())
    val rootCap = matrix.firstOrNull { it.id == "cpu_gpu_overclocking" }
    assertNotNull(rootCap)
    assertTrue(rootCap!!.technicalGuardrail.contains("RucheSpace"))
  }

  @Test
  fun testShizukuStateRepresentations() {
    val grantedState = com.example.data.model.ShizukuState(
      isServiceAvailable = true,
      isBinderAlive = true,
      isPermissionGranted = true,
      shizukuVersion = 13,
      serverUid = 2000,
      connectionStatusText = "Authorized"
    )
    assertTrue(grantedState.isBinderAlive && grantedState.isPermissionGranted)

    val deniedState = com.example.data.model.ShizukuState(
      isServiceAvailable = true,
      isBinderAlive = true,
      isPermissionGranted = false,
      shizukuVersion = 13,
      serverUid = 2000,
      connectionStatusText = "Permission Required"
    )
    assertTrue(deniedState.isBinderAlive && !deniedState.isPermissionGranted)

    val offlineState = com.example.data.model.ShizukuState(
      isServiceAvailable = false,
      isBinderAlive = false,
      isPermissionGranted = false,
      shizukuVersion = 0,
      serverUid = -1,
      connectionStatusText = "Offline"
    )
    assertTrue(!offlineState.isBinderAlive)
  }
}
