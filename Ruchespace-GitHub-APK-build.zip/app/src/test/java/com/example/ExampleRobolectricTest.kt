package com.example

import com.example.data.hardware.HardwareInspector
import com.example.data.model.BatteryTelemetry
import com.example.data.model.BottleneckType
import com.example.data.model.MemoryTelemetry
import com.example.data.model.ThermalInfo
import com.example.data.model.ThermalStatusLevel
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleRobolectricTest {

  @Test
  fun testBottleneckDiagnosisThermal() {
    val thermalThrottling = ThermalInfo(
      statusLevel = ThermalStatusLevel.CRITICAL,
      thermalHeadroom = 1.0f,
      isThrottlingActive = true,
      diagnosticTip = "Test critical thermal"
    )

    val battery = BatteryTelemetry(
      levelPercent = 80,
      temperatureCelsius = 43.5f,
      voltageMv = 4000,
      isCharging = false,
      chargingStatus = "Discharging",
      health = "Good",
      powerWattageEstimate = 1.2f
    )

    val memory = MemoryTelemetry(
      totalRamMb = 8192,
      availableRamMb = 4096,
      usedRamPercent = 50,
      isLowMemory = false,
      lowMemoryThresholdMb = 1024,
      totalStorageGb = 128f,
      freeStorageGb = 64f
    )

    // Using null-safe instantiation or mock-free call
    val observations = mutableListOf<String>()
    val isThrottling = thermalThrottling.isThrottlingActive || battery.temperatureCelsius >= 41.5f
    val bottleneck = if (isThrottling) BottleneckType.HEAT_THROTTLING else BottleneckType.BALANCED

    assertEquals(BottleneckType.HEAT_THROTTLING, bottleneck)
  }

  @Test
  fun testResolutionScaleCalculations() {
    val nativeW = 1080
    val nativeH = 2400
    val scale85 = 85 / 100f

    val w85 = ((nativeW * scale85).toInt() / 8) * 8
    val h85 = ((nativeH * scale85).toInt() / 8) * 8

    assertEquals(912, w85)
    assertEquals(2040, h85)
  }
}
