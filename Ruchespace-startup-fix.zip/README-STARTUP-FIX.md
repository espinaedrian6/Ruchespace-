Ruchespace startup compatibility patch

Main fix: DisplayManagerHelper no longer calls Context.display using the Application context. On Android 11+ that API is not valid for an Application context and can throw UnsupportedOperationException during ViewModel initialization, before the dashboard appears. It now gets the default display through DisplayManager with a legacy fallback.

Also removed unused Firebase/App Check and Google Services/Secrets Gradle integrations, and removed the custom debug keystore reference so the standard Gradle debug signing key is used.

Build with: gradle :app:assembleDebug (JDK 17, Gradle 9.3.1).
