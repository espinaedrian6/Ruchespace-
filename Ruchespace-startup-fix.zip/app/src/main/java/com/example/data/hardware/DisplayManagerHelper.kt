package com.example.data.hardware

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.util.DisplayMetrics
import android.view.Display
import android.view.WindowManager
import com.example.data.model.DisplayDeviceInfo
import com.example.data.model.DisplayResolutionMode
import com.example.data.model.ResolutionScalingPreset
import kotlin.math.roundToInt
import kotlin.math.sqrt

class DisplayManagerHelper(private val context: Context) {

  private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
  private val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager

  @Suppress("DEPRECATION")
  fun getDisplayDeviceInfo(): DisplayDeviceInfo {
    // This helper is constructed with the Application context by the ViewModel.
    // Context.display is not valid for an Application context on Android 11+ and
    // can throw UnsupportedOperationException, which would crash app startup.
    // DisplayManager is safe to use with the Application context.
    val display: Display = displayManager.getDisplay(Display.DEFAULT_DISPLAY)
      ?: windowManager.defaultDisplay

    val metrics = DisplayMetrics()
    display.getRealMetrics(metrics)

    val currentMode = display.mode
    val currentWidth = metrics.widthPixels
    val currentHeight = metrics.heightPixels
    val densityDpi = metrics.densityDpi
    val densityScale = metrics.density
    val currentRefreshRate = display.refreshRate

    val supportedModes = display.supportedModes.map { mode ->
      DisplayResolutionMode(
        id = mode.modeId,
        width = mode.physicalWidth,
        height = mode.physicalHeight,
        refreshRate = mode.refreshRate,
        isCurrent = mode.modeId == currentMode.modeId,
        isNative = mode.physicalWidth == currentWidth && mode.physicalHeight == currentHeight
      )
    }.distinctBy { "${it.width}x${it.height}@${it.refreshRate.roundToInt()}" }
      .sortedWith(compareByDescending<DisplayResolutionMode> { it.refreshRate }.thenByDescending { it.width })

    val supportedRefreshRates = supportedModes
      .map { (it.refreshRate * 10f).roundToInt() / 10f }
      .distinct()
      .sorted()

    val hdrSupported = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      display.hdrCapabilities?.supportedHdrTypes?.isNotEmpty() == true
    } else false

    val wideColorGamut = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      display.isWideColorGamut
    } else false

    val widthInches = metrics.widthPixels / metrics.xdpi
    val heightInches = metrics.heightPixels / metrics.ydpi
    val physicalSizeInches = sqrt((widthInches * widthInches + heightInches * heightInches).toDouble()).toFloat()

    return DisplayDeviceInfo(
      currentWidth = currentWidth,
      currentHeight = currentHeight,
      densityDpi = densityDpi,
      densityScale = densityScale,
      currentRefreshRate = currentRefreshRate,
      supportedModes = supportedModes,
      supportedRefreshRates = supportedRefreshRates,
      hdrSupported = hdrSupported,
      wideColorGamut = wideColorGamut,
      physicalSizeInches = if (physicalSizeInches in 3.0f..15.0f) physicalSizeInches else 6.5f
    )
  }

  fun getResolutionScalingPresets(baseInfo: DisplayDeviceInfo): List<ResolutionScalingPreset> {
    val nativeW = baseInfo.currentWidth
    val nativeH = baseInfo.currentHeight
    val nativeDpi = baseInfo.densityDpi

    fun calculateScaled(percent: Int): Triple<Int, Int, Int> {
      val scale = percent / 100f
      // Round to multiple of 8 for GPU alignment
      val w = ((nativeW * scale).toInt() / 8) * 8
      val h = ((nativeH * scale).toInt() / 8) * 8
      val dpi = (nativeDpi * scale).toInt()
      return Triple(w, h, dpi)
    }

    val (w85, h85, dpi85) = calculateScaled(85)
    val (w75, h75, dpi75) = calculateScaled(75)
    val (w60, h60, dpi60) = calculateScaled(60)

    return listOf(
      ResolutionScalingPreset(
        id = "scale_100",
        name = "100% Native Resolution",
        scalePercent = 100,
        targetWidth = nativeW,
        targetHeight = nativeH,
        targetDensityDpi = nativeDpi,
        description = "Standard display resolution. Maximum visual sharpness, crisp typography, and full pixel density.",
        expectedGpuRelief = "Baseline (0% reduction)",
        clarityImpact = "Flawless clarity (Native panel pixel mapping)",
        safetyNotice = "Default factory state. 100% safe."
      ),
      ResolutionScalingPreset(
        id = "scale_85",
        name = "85% Balanced Scaling",
        scalePercent = 85,
        targetWidth = w85,
        targetHeight = h85,
        targetDensityDpi = dpi85,
        description = "Reduces total fragment shader rasterization by ~27% while preserving crisp character details.",
        expectedGpuRelief = "~25-30% reduction in GPU pixel fill-rate load",
        clarityImpact = "Minimal blurriness, text remains sharp",
        safetyNotice = "Reversible via 1-tap restore or auto-revert countdown."
      ),
      ResolutionScalingPreset(
        id = "scale_75",
        name = "75% Performance Scaling",
        scalePercent = 75,
        targetWidth = w75,
        targetHeight = h75,
        targetDensityDpi = dpi75,
        description = "Cuts rendered pixel count by nearly 44%. Recommended for heavy 3D titles on mid-tier SoCs.",
        expectedGpuRelief = "~40-45% reduction in GPU pixel fill-rate load",
        clarityImpact = "Slight softening of UI edges and fine text",
        safetyNotice = "Always test with 10-second confirmation preview."
      ),
      ResolutionScalingPreset(
        id = "scale_60",
        name = "60% Battery Saver Scaling",
        scalePercent = 60,
        targetWidth = w60,
        targetHeight = h60,
        targetDensityDpi = dpi60,
        description = "Maximum GPU power savings. Renders only 36% of native pixels. Keeps device cool during long sessions.",
        expectedGpuRelief = "~60% reduction in GPU rendering workload",
        clarityImpact = "Noticeable downsampling blur in high-contrast text",
        safetyNotice = "Extreme mode. Auto-revert protection active."
      )
    )
  }
}
